import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  User,
  Product,
  ServiceItem,
  RFQItem,
  Order,
  MessageItem,
  Coupon,
  PlatformSettings,
} from '../src/types/index.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

// Security helper: hash password with salt
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || !storedHash.includes(':')) return false;
  const [salt, key] = storedHash.split(':');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(key, 'hex'), Buffer.from(hash, 'hex'));
}

export function normalizePhone(rawPhone: string): string {
  let cleaned = rawPhone.replace(/\D/g, '');
  if (cleaned.startsWith('258')) {
    cleaned = cleaned.substring(3);
  }
  // If 9 digits starting with 8, it's a valid MZ phone
  if (cleaned.length === 9) {
    return `+258${cleaned}`;
  }
  if (cleaned.length > 9) {
    return `+${cleaned}`;
  }
  return `+258${cleaned}`;
}

export interface StoredUser extends User {
  passwordHash: string;
}

export interface DatabaseSchema {
  users: StoredUser[];
  sessions: { [token: string]: { userId: string; expiresAt: number } };
  products: Product[];
  services: ServiceItem[];
  rfqs: RFQItem[];
  orders: Order[];
  messages: MessageItem[];
  coupons: Coupon[];
  settings: PlatformSettings;
  auditLogs: Array<{ id: string; action: string; details: string; actorPhone: string; timestamp: string }>;
}

const DEFAULT_SETTINGS: PlatformSettings = {
  commissionRatePercent: 5,
  mpesaNumber: '84 712 3456',
  mpesaAccountName: 'Moz Fácil Fal Lda - M-Pesa Negócios',
  emolaNumber: '86 912 3456',
  emolaAccountName: 'Moz Fácil Fal Lda - e-Mola Comercial',
  supportPhone: '+258 84 712 3456',
  supportWhatsapp: '+258 84 712 3456',
};

function getSeedData(): DatabaseSchema {
  const adminPass = hashPassword('admin123');
  const sellerPass = hashPassword('vendedor123');
  const buyerPass = hashPassword('cliente123');

  const now = new Date().toISOString();

  return {
    users: [
      {
        id: 'user_admin',
        phone: '+258840000000',
        name: 'Administração Moz Fácil Fal',
        role: 'admin',
        businessName: 'Moz Fácil Fal Marketplace S.A.',
        province: 'Maputo Cidade',
        city: 'Maputo Central',
        isVerified: true,
        createdAt: now,
        passwordHash: adminPass,
      },
      {
        id: 'user_seller_1',
        phone: '+258841234567',
        name: 'Carlos Malauene',
        role: 'seller',
        businessName: 'AgroMoçambique Export & Distribuição',
        province: 'Nampula',
        city: 'Nampula Cidade',
        isVerified: true,
        createdAt: now,
        passwordHash: sellerPass,
      },
      {
        id: 'user_seller_2',
        phone: '+258857654321',
        name: 'Fatima Chissano',
        role: 'seller',
        businessName: 'ElectroSolar & Tech Maputo',
        province: 'Maputo Cidade',
        city: 'Polana Caniço / 24 de Julho',
        isVerified: true,
        createdAt: now,
        passwordHash: sellerPass,
      },
      {
        id: 'user_seller_3',
        phone: '+258869876543',
        name: 'António Machava',
        role: 'seller',
        businessName: 'Construções & Ferragens do Centro',
        province: 'Sofala',
        city: 'Beira - Munhava',
        isVerified: true,
        createdAt: now,
        passwordHash: sellerPass,
      },
      {
        id: 'user_buyer_1',
        phone: '+258823456789',
        name: 'Nelson Tembe',
        role: 'buyer',
        province: 'Maputo Cidade',
        city: 'Costa do Sol',
        isVerified: true,
        createdAt: now,
        passwordHash: buyerPass,
      },
    ],
    sessions: {},
    products: [
      {
        id: 'prod_1',
        sellerId: 'user_seller_1',
        sellerName: 'AgroMoçambique Export & Distribuição',
        sellerPhone: '+258841234567',
        sellerCity: 'Nampula',
        title: 'Castanha de Caju Bruta Grau A — Sacos 50kg Exportação & Retalho',
        description: 'Castanha de caju moçambicana de primeira qualidade colhida na província de Nampula. Alto rendimento KOR (48-52 lbs), baixa humidade (menos de 8%), pronta para descasque ou revenda no mercado nacional e internacional. Entregas disponíveis via ferrovia e camião para todo Moçambique.',
        price: 3400, // MTn por saco
        wholesalePrice: 3100,
        wholesaleMinQty: 10,
        unitType: 'saco',
        moq: 2,
        stock: 450,
        category: 'Agricultura & Alimentos',
        subcategory: 'Castanhas & Oleaginosas',
        images: ['/src/assets/images/product_agri_produce_1792475627909.jpg'],
        deliveryInfo: 'Despacho em 24h a 48h a partir de Nampula. Frete para Beira e Maputo negociável.',
        status: 'ativo',
        rating: 4.9,
        reviewCount: 38,
        createdAt: now,
      },
      {
        id: 'prod_2',
        sellerId: 'user_seller_2',
        sellerName: 'ElectroSolar & Tech Maputo',
        sellerPhone: '+258857654321',
        sellerCity: 'Maputo Cidade',
        title: 'Central Solar Portátil 1200W com Painel Dobrável & Baterias LiFePO4',
        description: 'Gerador solar de alta durabilidade para residências, quintas e pequenas empresas. Capacidade de 1024Wh, saídas AC 220V senoidal pura, portas USB-C rápidas de 100W e lanternas LED integradas. Ideal para cortes de energia ou áreas rurais sem rede EDM.',
        price: 46500, // MTn
        wholesalePrice: 42000,
        wholesaleMinQty: 3,
        unitType: 'conjunto',
        moq: 1,
        stock: 35,
        category: 'Tecnologia & Eletrónica',
        subcategory: 'Energia Solar & Baterias',
        images: ['/src/assets/images/product_electronics_solar_1792475628923.jpg'],
        deliveryInfo: 'Entrega grátis na Grande Maputo (Maputo e Matola). Envio via transportadora para as províncias.',
        status: 'ativo',
        rating: 4.8,
        reviewCount: 24,
        createdAt: now,
      },
      {
        id: 'prod_3',
        sellerId: 'user_seller_3',
        sellerName: 'Construções & Ferragens do Centro',
        sellerPhone: '+258869876543',
        sellerCity: 'Beira',
        title: 'Azulejos Porcelanato 60x60 Retificado & Cimento Portland 42.5N',
        description: 'Materiais de construção civil de alta resistência para obras residenciais e industriais. Azulejos antiderrapantes e cimento estrutural certificado. Temos stock permanente em armazém para pronto levantamento ou entrega no estaleiro da sua obra.',
        price: 850, // MTn por m² / saco
        wholesalePrice: 780,
        wholesaleMinQty: 50,
        unitType: 'metro',
        moq: 10,
        stock: 2500,
        category: 'Construção & Ferragens',
        subcategory: 'Pavimentos & Cimento',
        images: ['/src/assets/images/product_construction_hardware_1792475629674.jpg'],
        deliveryInfo: 'Carrinha de transporte disponível para entregas na província de Sofala e Manica.',
        status: 'ativo',
        rating: 4.7,
        reviewCount: 19,
        createdAt: now,
      },
      {
        id: 'prod_4',
        sellerId: 'user_seller_1',
        sellerName: 'AgroMoçambique Export & Distribuição',
        sellerPhone: '+258841234567',
        sellerCity: 'Nampula',
        title: 'Milho Branco Moçambicano Grão Seco Não-OGM (Sacos 50kg)',
        description: 'Milho branco limpo, seco e peneirado, cultivado em regime familiar sustentável no norte do país. Excelente para moagem e produção de farinha de milho (chima). Sacos devidamente identificados.',
        price: 1650,
        wholesalePrice: 1450,
        wholesaleMinQty: 20,
        unitType: 'saco',
        moq: 5,
        stock: 800,
        category: 'Agricultura & Alimentos',
        subcategory: 'Cereais & Farinhas',
        images: ['/src/assets/images/product_agri_produce_1792475627909.jpg'],
        deliveryInfo: 'Carregamentos a granel ou sacos para todo o país.',
        status: 'ativo',
        rating: 4.9,
        reviewCount: 42,
        createdAt: now,
      },
      {
        id: 'prod_5',
        sellerId: 'user_seller_2',
        sellerName: 'ElectroSolar & Tech Maputo',
        sellerPhone: '+258857654321',
        sellerCity: 'Maputo Cidade',
        title: 'Smartphone Robusto 5G Dual SIM Bateria 10600mAh com Lanterna Camping',
        description: 'Telefone blindado resistente a poeiras, quedas e água (IP68/IP69K). Perfeito para trabalho de campo em agricultura, mineração e transportes em Moçambique. Memória 256GB + 12GB RAM, suporte a todas as redes nacionais (Vodacom, Movitel, Tmcel).',
        price: 19800,
        wholesalePrice: 17500,
        wholesaleMinQty: 5,
        unitType: 'unidade',
        moq: 1,
        stock: 28,
        category: 'Tecnologia & Eletrónica',
        subcategory: 'Smartphones & Tablets',
        images: ['/src/assets/images/product_electronics_solar_1792475628923.jpg'],
        deliveryInfo: 'Entrega no mesmo dia em Maputo/Matola. Garantia nacional de 12 meses.',
        status: 'ativo',
        rating: 5.0,
        reviewCount: 15,
        createdAt: now,
      },
    ],
    services: [
      {
        id: 'serv_1',
        providerId: 'user_seller_2',
        providerName: 'Laboratório Tech Repair Moçambique',
        providerPhone: '+258857654321',
        providerCity: 'Maputo Cidade',
        title: 'Reparação Especializada de Telemóveis, Laptops & Placas Eletrónicas',
        description: 'Serviço técnico com microscópio, soldadura BGA e diagnóstico digital. Troca de telas originais, recuperação de aparelhos caídos em água, substituição de baterias e reparações em motherboards com 3 meses de garantia.',
        category: 'Reparação & Assistência Técnica',
        price: 1500,
        isNegotiable: true,
        priceUnit: 'por diagnóstico / reparação',
        images: ['/src/assets/images/service_technician_repair_1792475629469.jpg'],
        availability: 'Segunda a Sábado, 08h00 às 18h00',
        isVerified: true,
        rating: 4.9,
        reviewCount: 52,
        createdAt: now,
      },
      {
        id: 'serv_2',
        providerId: 'user_seller_3',
        providerName: 'Machava Eletricistas & Canalizadores',
        providerPhone: '+258869876543',
        providerCity: 'Beira',
        title: 'Instalação Elétrica Predial, Bombas de Água & Canalização Sanitária',
        description: 'Equipa de técnicos credenciados para montagem de quadros elétricos, ligação a geradores, instalação de autoclismos, bombas submersíveis e reparação de fugas de água em residências e indústrias.',
        category: 'Eletricistas & Canalizadores',
        price: 2500,
        isNegotiable: true,
        priceUnit: 'por serviço base',
        images: ['/src/assets/images/product_construction_hardware_1792475629674.jpg'],
        availability: 'Atendimento 24h para emergências',
        isVerified: true,
        rating: 4.8,
        reviewCount: 31,
        createdAt: now,
      },
      {
        id: 'serv_3',
        providerId: 'user_seller_1',
        providerName: 'Nampula Fretes & Logística Express',
        providerPhone: '+258841234567',
        providerCity: 'Nampula / Nacala / Beira',
        title: 'Transporte de Cargas & Mercadorias Pesadas com Rastreio GPS',
        description: 'Frotas de camiões basculantes e carrinhas fechadas para distribuição de produtos agrícolas, materiais de construção e encomendas comerciais no corredor Norte-Centro-Sul.',
        category: 'Transporte & Cargas',
        price: 8000,
        isNegotiable: true,
        priceUnit: 'por viagem / tonelada',
        images: ['/src/assets/images/hero_moz_marketplace_1792475627934.jpg'],
        availability: 'Agendamento imediato',
        isVerified: true,
        rating: 4.7,
        reviewCount: 28,
        createdAt: now,
      },
    ],
    rfqs: [
      {
        id: 'rfq_1',
        buyerId: 'user_buyer_1',
        buyerName: 'Nelson Tembe',
        buyerPhone: '+258823456789',
        title: 'Cotação para 200 Sacos de Cimento Portland 42.5N para Obra em Boane',
        category: 'Construção & Ferragens',
        description: 'Preciso de cotação com entrega incluída no estaleiro em Boane para 200 sacos de cimento de alta resistência. Descarregamento no local necessário.',
        quantity: 200,
        targetPrice: 750,
        city: 'Boane / Maputo Província',
        status: 'aberto',
        quotes: [
          {
            id: 'quote_1',
            sellerId: 'user_seller_3',
            sellerName: 'Construções & Ferragens do Centro',
            sellerPhone: '+258869876543',
            price: 760,
            notes: 'Conseguimos fornecer 200 sacos com entrega em 48h com camião grua.',
            createdAt: now,
          },
        ],
        createdAt: now,
      },
    ],
    orders: [
      {
        id: 'ord_1',
        orderNumber: 'MOZ-2026-1001',
        buyerId: 'user_buyer_1',
        buyerName: 'Nelson Tembe',
        buyerPhone: '+258823456789',
        deliveryAddress: {
          province: 'Maputo Cidade',
          city: 'Costa do Sol',
          street: 'Av. Marginal, Rua dos Pescadores nº 45',
          notes: 'Ligar antes de chegar',
        },
        items: [
          {
            productId: 'prod_5',
            title: 'Smartphone Robusto 5G Dual SIM Bateria 10600mAh',
            price: 19800,
            quantity: 1,
            unitType: 'unidade',
            sellerId: 'user_seller_2',
            sellerName: 'ElectroSolar & Tech Maputo',
            image: '/src/assets/images/product_electronics_solar_1792475628923.jpg',
          },
        ],
        subtotal: 19800,
        discount: 500,
        deliveryFee: 350,
        total: 19650,
        commissionRate: 0.05,
        commissionAmount: 990,
        sellerPayout: 18810,
        status: 'pago',
        paymentMethod: 'mpesa',
        paymentReference: 'CI9892KJ402',
        paymentNote: 'Pago via M-Pesa pelo número 823456789 às 14:22',
        verifiedBy: 'user_admin',
        verifiedAt: now,
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        updatedAt: now,
      },
    ],
    messages: [
      {
        id: 'msg_1',
        threadId: 'th_buyer1_seller2_prod5',
        senderId: 'user_buyer_1',
        senderName: 'Nelson Tembe',
        receiverId: 'user_seller_2',
        receiverName: 'ElectroSolar & Tech Maputo',
        content: 'Boa tarde! O smartphone tem mesmo garantia de 12 meses em Maputo?',
        referenceType: 'product',
        referenceId: 'prod_5',
        referenceTitle: 'Smartphone Robusto 5G Dual SIM',
        isRead: true,
        createdAt: new Date(Date.now() - 90000000).toISOString(),
      },
      {
        id: 'msg_2',
        threadId: 'th_buyer1_seller2_prod5',
        senderId: 'user_seller_2',
        senderName: 'ElectroSolar & Tech Maputo',
        receiverId: 'user_buyer_1',
        receiverName: 'Nelson Tembe',
        content: 'Boa tarde Sr. Nelson! Sim, garantia oficial com assistência técnica direta na nossa oficina na Av. 24 de Julho.',
        referenceType: 'product',
        referenceId: 'prod_5',
        referenceTitle: 'Smartphone Robusto 5G Dual SIM',
        isRead: true,
        createdAt: new Date(Date.now() - 89000000).toISOString(),
      },
    ],
    coupons: [
      {
        code: 'BEMVINDO10',
        discountPercent: 10,
        minOrderAmount: 1000,
        description: '10% de desconto na sua primeira compra em Moçambique',
        expiryDate: '2027-12-31',
        isActive: true,
      },
      {
        code: 'MOZFACIL500',
        discountFixed: 500,
        minOrderAmount: 3000,
        description: '500 MTn de desconto em encomendas superiores a 3.000 MTn',
        expiryDate: '2027-12-31',
        isActive: true,
      },
    ],
    settings: DEFAULT_SETTINGS,
    auditLogs: [
      {
        id: 'audit_1',
        action: 'SISTEMA_INICIALIZADO',
        details: 'Base de dados inicializada com regras de moderação e pagamentos de Moçambique',
        actorPhone: 'SISTEMA',
        timestamp: now,
      },
    ],
  };
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.ensureDir();
    this.data = this.load();
  }

  private ensureDir() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        // Ensure all top-level keys exist
        if (!parsed.settings) parsed.settings = DEFAULT_SETTINGS;
        if (!parsed.auditLogs) parsed.auditLogs = [];
        return parsed;
      }
    } catch (e) {
      console.error('Erro ao ler base de dados JSON, reinicializando...', e);
    }
    const initial = getSeedData();
    this.saveDirect(initial);
    return initial;
  }

  private saveDirect(data: DatabaseSchema) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Erro ao salvar ficheiro JSON:', err);
    }
  }

  public save() {
    this.saveDirect(this.data);
  }

  public getSchema(): DatabaseSchema {
    return this.data;
  }

  // User management
  public findUserByPhone(phone: string): StoredUser | undefined {
    const normalized = normalizePhone(phone);
    return this.data.users.find((u) => u.phone === normalized);
  }

  public findUserById(id: string): StoredUser | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public createUser(user: StoredUser): StoredUser {
    this.data.users.push(user);
    this.save();
    return user;
  }

  public updateUser(id: string, updates: Partial<StoredUser>): StoredUser | null {
    const idx = this.data.users.findIndex((u) => u.id === id);
    if (idx === -1) return null;
    this.data.users[idx] = { ...this.data.users[idx], ...updates };
    this.save();
    return this.data.users[idx];
  }

  // Session management
  public createSession(userId: string): string {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 1000 * 60 * 60 * 24 * 30; // 30 days
    this.data.sessions[token] = { userId, expiresAt };
    this.save();
    return token;
  }

  public getUserByToken(token: string): User | null {
    const session = this.data.sessions[token];
    if (!session) return null;
    if (session.expiresAt < Date.now()) {
      delete this.data.sessions[token];
      this.save();
      return null;
    }
    const user = this.findUserById(session.userId);
    if (!user) return null;
    // Return user without passwordHash
    const { passwordHash, ...cleanUser } = user;
    return cleanUser;
  }

  public destroySession(token: string) {
    if (this.data.sessions[token]) {
      delete this.data.sessions[token];
      this.save();
    }
  }

  // Products
  public getProducts(): Product[] {
    return this.data.products;
  }

  public getProductById(id: string): Product | undefined {
    return this.data.products.find((p) => p.id === id);
  }

  public addProduct(product: Product): Product {
    this.data.products.unshift(product);
    this.save();
    return product;
  }

  public updateProduct(id: string, updates: Partial<Product>): Product | null {
    const idx = this.data.products.findIndex((p) => p.id === id);
    if (idx === -1) return null;
    this.data.products[idx] = { ...this.data.products[idx], ...updates };
    this.save();
    return this.data.products[idx];
  }

  public deleteProduct(id: string): boolean {
    const initialLen = this.data.products.length;
    this.data.products = this.data.products.filter((p) => p.id !== id);
    if (this.data.products.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // Services
  public getServices(): ServiceItem[] {
    return this.data.services;
  }

  public getServiceById(id: string): ServiceItem | undefined {
    return this.data.services.find((s) => s.id === id);
  }

  public addService(service: ServiceItem): ServiceItem {
    this.data.services.unshift(service);
    this.save();
    return service;
  }

  public updateService(id: string, updates: Partial<ServiceItem>): ServiceItem | null {
    const idx = this.data.services.findIndex((s) => s.id === id);
    if (idx === -1) return null;
    this.data.services[idx] = { ...this.data.services[idx], ...updates };
    this.save();
    return this.data.services[idx];
  }

  public deleteService(id: string): boolean {
    const initialLen = this.data.services.length;
    this.data.services = this.data.services.filter((s) => s.id !== id);
    if (this.data.services.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // RFQs
  public getRFQs(): RFQItem[] {
    return this.data.rfqs;
  }

  public addRFQ(rfq: RFQItem): RFQItem {
    this.data.rfqs.unshift(rfq);
    this.save();
    return rfq;
  }

  public addQuoteToRFQ(rfqId: string, quote: any): RFQItem | null {
    const rfq = this.data.rfqs.find((r) => r.id === rfqId);
    if (!rfq) return null;
    rfq.quotes.push(quote);
    rfq.status = 'em_negociacao';
    this.save();
    return rfq;
  }

  // Orders
  public getOrders(): Order[] {
    return this.data.orders;
  }

  public getOrderById(id: string): Order | undefined {
    return this.data.orders.find((o) => o.id === id);
  }

  public addOrder(order: Order): Order {
    this.data.orders.unshift(order);
    this.save();
    return order;
  }

  public updateOrder(id: string, updates: Partial<Order>): Order | null {
    const idx = this.data.orders.findIndex((o) => o.id === id);
    if (idx === -1) return null;
    this.data.orders[idx] = { ...this.data.orders[idx], ...updates, updatedAt: new Date().toISOString() };
    this.save();
    return this.data.orders[idx];
  }

  // Messages
  public getMessages(userId: string): MessageItem[] {
    return this.data.messages.filter((m) => m.senderId === userId || m.receiverId === userId);
  }

  public addMessage(message: MessageItem): MessageItem {
    this.data.messages.push(message);
    this.save();
    return message;
  }

  // Coupons
  public findCoupon(code: string): Coupon | undefined {
    const cleanCode = code.trim().toUpperCase();
    return this.data.coupons.find((c) => c.code === cleanCode && c.isActive);
  }

  // Settings
  public getSettings(): PlatformSettings {
    return this.data.settings;
  }

  public updateSettings(newSettings: Partial<PlatformSettings>): PlatformSettings {
    this.data.settings = { ...this.data.settings, ...newSettings };
    this.save();
    return this.data.settings;
  }

  // Audit
  public addAuditLog(action: string, details: string, actorPhone: string) {
    this.data.auditLogs.unshift({
      id: 'audit_' + Date.now(),
      action,
      details,
      actorPhone,
      timestamp: new Date().toISOString(),
    });
    // Keep max 200 logs
    if (this.data.auditLogs.length > 200) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 200);
    }
    this.save();
  }

  public getAuditLogs() {
    return this.data.auditLogs;
  }
}

export const db = new Database();
