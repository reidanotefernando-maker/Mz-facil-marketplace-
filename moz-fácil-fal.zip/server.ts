import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import {
  db,
  normalizePhone,
  hashPassword,
  verifyPassword,
} from './server/db.ts';
import {
  Product,
  ServiceItem,
  RFQItem,
  Order,
  OrderItem,
  MessageItem,
} from './src/types/index.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Auth Middleware
interface AuthRequest extends Request {
  user?: any;
}

function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }
  const token = authHeader.substring(7);
  const user = db.getUserByToken(token);
  if (user) {
    req.user = user;
  }
  next();
}

app.use(authMiddleware);

function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Autenticação necessária. Por favor inicie sessão com o seu telefone.' });
  }
  next();
}

function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Acesso negado. Apenas administradores autorizados.' });
  }
  next();
}

// Rate-limiting / Login attempt cache in memory
const loginAttempts: Record<string, { count: number; lockedUntil: number }> = {};

// ==========================================
// 1. AUTH ROUTES (Phone & Password)
// ==========================================

app.post('/api/auth/register', (req: Request, res: Response) => {
  const { name, phone, password, role = 'buyer', businessName, province, city } = req.body;

  if (!name || !phone || !password) {
    return res.status(400).json({ error: 'Nome, número de telefone e palavra-passe são obrigatórios.' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'A palavra-passe deve conter pelo menos 6 caracteres.' });
  }

  const normalized = normalizePhone(phone);
  if (normalized.length < 9) {
    return res.status(400).json({ error: 'Número de telefone moçambicano inválido. Exemplo: 841234567' });
  }

  const existing = db.findUserByPhone(normalized);
  if (existing) {
    return res.status(409).json({ error: 'Já existe uma conta registada com este número de telefone.' });
  }

  const passwordHash = hashPassword(password);
  const newUser = {
    id: 'user_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    phone: normalized,
    name: name.trim(),
    role: (role === 'seller' ? 'seller' : 'buyer') as 'buyer' | 'seller',
    businessName: businessName ? businessName.trim() : undefined,
    province: province || 'Maputo Cidade',
    city: city || 'Maputo',
    isVerified: false,
    createdAt: new Date().toISOString(),
    passwordHash,
  };

  db.createUser(newUser);
  const token = db.createSession(newUser.id);
  const { passwordHash: _, ...userSafe } = newUser;

  db.addAuditLog('REGISTO_UTILIZADOR', `Novo utilizador criado: ${userSafe.name} (${normalized})`, normalized);

  res.json({ token, user: userSafe });
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { phone, password } = req.body;
  if (!phone || !password) {
    return res.status(400).json({ error: 'Informe o número de telefone e a palavra-passe.' });
  }

  const normalized = normalizePhone(phone);
  const attempt = loginAttempts[normalized];
  if (attempt && attempt.lockedUntil > Date.now()) {
    const waitSec = Math.ceil((attempt.lockedUntil - Date.now()) / 1000);
    return res.status(429).json({ error: `Demasiadas tentativas falhadas. Aguarde ${waitSec} segundos antes de tentar novamente.` });
  }

  const user = db.findUserByPhone(normalized);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    if (!loginAttempts[normalized]) {
      loginAttempts[normalized] = { count: 1, lockedUntil: 0 };
    } else {
      loginAttempts[normalized].count += 1;
      if (loginAttempts[normalized].count >= 5) {
        loginAttempts[normalized].lockedUntil = Date.now() + 60 * 1000; // 1 min lock
      }
    }
    return res.status(401).json({ error: 'Número de telefone ou palavra-passe incorretos.' });
  }

  // Reset login attempts on success
  delete loginAttempts[normalized];

  const token = db.createSession(user.id);
  const { passwordHash: _, ...userSafe } = user;

  res.json({ token, user: userSafe });
});

app.get('/api/auth/me', (req: AuthRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ user: null });
  }
  res.json({ user: req.user });
});

app.post('/api/auth/logout', (req: AuthRequest, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    db.destroySession(authHeader.substring(7));
  }
  res.json({ success: true });
});

app.post('/api/auth/become-seller', requireAuth, (req: AuthRequest, res: Response) => {
  const { businessName, province, city } = req.body;
  if (!businessName) {
    return res.status(400).json({ error: 'O nome da empresa ou atividade comercial é obrigatório.' });
  }
  const updated = db.updateUser(req.user.id, {
    role: 'seller',
    businessName: businessName.trim(),
    province: province || req.user.province,
    city: city || req.user.city,
  });
  if (!updated) return res.status(404).json({ error: 'Utilizador não encontrado.' });
  const { passwordHash: _, ...safe } = updated;
  db.addAuditLog('UTILIZADOR_TORNOU_SE_VENDEDOR', `Utilizador ${safe.name} ativou perfil de vendedor: ${businessName}`, safe.phone);
  res.json({ user: safe });
});

// ==========================================
// 2. PRODUCTS API
// ==========================================

app.get('/api/products', (req: Request, res: Response) => {
  let list = db.getProducts();

  const { search, category, minPrice, maxPrice, city, sort, sellerId, onlyActive } = req.query;

  // Filter by seller
  if (sellerId) {
    list = list.filter((p) => p.sellerId === String(sellerId));
  } else if (onlyActive !== 'false') {
    // Only show active approved products for general catalog
    list = list.filter((p) => p.status === 'ativo');
  }

  if (category && category !== 'Todas') {
    list = list.filter((p) => p.category.toLowerCase().includes(String(category).toLowerCase()));
  }

  if (city && city !== 'Todas as Províncias') {
    list = list.filter((p) => p.sellerCity.toLowerCase().includes(String(city).toLowerCase()));
  }

  if (minPrice) {
    list = list.filter((p) => p.price >= Number(minPrice));
  }

  if (maxPrice) {
    list = list.filter((p) => p.price <= Number(maxPrice));
  }

  if (search) {
    const q = String(search).toLowerCase();
    list = list.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.sellerName.toLowerCase().includes(q)
    );
  }

  // Sorting
  if (sort === 'price_asc') {
    list.sort((a, b) => a.price - b.price);
  } else if (sort === 'price_desc') {
    list.sort((a, b) => b.price - a.price);
  } else if (sort === 'rating') {
    list.sort((a, b) => b.rating - a.rating);
  } else {
    // Newest first
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  res.json(list);
});

app.get('/api/products/:id', (req: Request, res: Response) => {
  const prod = db.getProductById(req.params.id);
  if (!prod) {
    return res.status(404).json({ error: 'Produto não encontrado.' });
  }
  res.json(prod);
});

app.post('/api/products', requireAuth, (req: AuthRequest, res: Response) => {
  const {
    title,
    description,
    price,
    wholesalePrice,
    wholesaleMinQty,
    unitType = 'unidade',
    moq = 1,
    stock = 1,
    category,
    subcategory = '',
    images = [],
    deliveryInfo = '',
  } = req.body;

  if (!title || !description || price === undefined || !category) {
    return res.status(400).json({ error: 'Título, descrição, preço e categoria são obrigatórios.' });
  }

  const newProduct: Product = {
    id: 'prod_' + Date.now(),
    sellerId: req.user.id,
    sellerName: req.user.businessName || req.user.name,
    sellerPhone: req.user.phone,
    sellerCity: req.user.city || req.user.province || 'Maputo',
    title: title.trim(),
    description: description.trim(),
    price: Number(price),
    wholesalePrice: wholesalePrice ? Number(wholesalePrice) : undefined,
    wholesaleMinQty: wholesaleMinQty ? Number(wholesaleMinQty) : undefined,
    unitType,
    moq: Math.max(1, Number(moq)),
    stock: Math.max(0, Number(stock)),
    category,
    subcategory,
    images: images.length > 0 ? images : ['/src/assets/images/product_construction_hardware_1792475629674.jpg'],
    deliveryInfo,
    status: req.user.role === 'admin' ? 'ativo' : 'ativo', // Approved by default or configurable
    rating: 5.0,
    reviewCount: 0,
    createdAt: new Date().toISOString(),
  };

  db.addProduct(newProduct);
  db.addAuditLog('PRODUTO_PUBLICADO', `Produto anunciado: ${newProduct.title} (${newProduct.price} MTn)`, req.user.phone);

  res.json(newProduct);
});

app.put('/api/products/:id', requireAuth, (req: AuthRequest, res: Response) => {
  const prod = db.getProductById(req.params.id);
  if (!prod) return res.status(404).json({ error: 'Produto não encontrado.' });
  if (prod.sellerId !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Permissão negada. Apenas o vendedor ou administrador podem editar este anúncio.' });
  }

  const updated = db.updateProduct(req.params.id, req.body);
  res.json(updated);
});

app.delete('/api/products/:id', requireAuth, (req: AuthRequest, res: Response) => {
  const prod = db.getProductById(req.params.id);
  if (!prod) return res.status(404).json({ error: 'Produto não encontrado.' });
  if (prod.sellerId !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Permissão negada.' });
  }
  db.deleteProduct(req.params.id);
  res.json({ success: true });
});

// ==========================================
// 3. SERVICES DIRECTORY API
// ==========================================

app.get('/api/services', (req: Request, res: Response) => {
  let list = db.getServices();
  const { search, category, location, providerId } = req.query;

  if (providerId) {
    list = list.filter((s) => s.providerId === String(providerId));
  }
  if (category && category !== 'Todos') {
    list = list.filter((s) => s.category.toLowerCase().includes(String(category).toLowerCase()));
  }
  if (location) {
    list = list.filter((s) => s.providerCity.toLowerCase().includes(String(location).toLowerCase()));
  }
  if (search) {
    const q = String(search).toLowerCase();
    list = list.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q) ||
        s.providerName.toLowerCase().includes(q)
    );
  }

  res.json(list);
});

app.post('/api/services', requireAuth, (req: AuthRequest, res: Response) => {
  const { title, description, category, price, isNegotiable = true, priceUnit = 'por serviço', images = [], availability = 'Disponível' } = req.body;

  if (!title || !description || !category) {
    return res.status(400).json({ error: 'Título, descrição e categoria são obrigatórios.' });
  }

  const newService: ServiceItem = {
    id: 'serv_' + Date.now(),
    providerId: req.user.id,
    providerName: req.user.businessName || req.user.name,
    providerPhone: req.user.phone,
    providerCity: req.user.city || req.user.province || 'Maputo',
    title: title.trim(),
    description: description.trim(),
    category,
    price: Number(price) || 0,
    isNegotiable: Boolean(isNegotiable),
    priceUnit,
    images: images.length > 0 ? images : ['/src/assets/images/service_technician_repair_1792475629469.jpg'],
    availability,
    isVerified: req.user.isVerified || false,
    rating: 5.0,
    reviewCount: 0,
    createdAt: new Date().toISOString(),
  };

  db.addService(newService);
  db.addAuditLog('SERVICO_PUBLICADO', `Serviço publicado: ${newService.title}`, req.user.phone);
  res.json(newService);
});

// ==========================================
// 4. RFQ / SOLICITAR ORÇAMENTO (Cotações)
// ==========================================

app.get('/api/rfqs', (req: Request, res: Response) => {
  res.json(db.getRFQs());
});

app.post('/api/rfqs', requireAuth, (req: AuthRequest, res: Response) => {
  const { title, category, description, quantity = 1, targetPrice, city } = req.body;
  if (!title || !description) {
    return res.status(400).json({ error: 'Título e descrição da cotação são obrigatórios.' });
  }

  const rfq: RFQItem = {
    id: 'rfq_' + Date.now(),
    buyerId: req.user.id,
    buyerName: req.user.name,
    buyerPhone: req.user.phone,
    title: title.trim(),
    category: category || 'Geral',
    description: description.trim(),
    quantity: Math.max(1, Number(quantity)),
    targetPrice: targetPrice ? Number(targetPrice) : undefined,
    city: city || req.user.city || 'Maputo',
    status: 'aberto',
    quotes: [],
    createdAt: new Date().toISOString(),
  };

  db.addRFQ(rfq);
  res.json(rfq);
});

app.post('/api/rfqs/:id/quote', requireAuth, (req: AuthRequest, res: Response) => {
  const { price, notes } = req.body;
  if (!price) {
    return res.status(400).json({ error: 'Preço cotado é obrigatório.' });
  }
  const quote = {
    id: 'quote_' + Date.now(),
    sellerId: req.user.id,
    sellerName: req.user.businessName || req.user.name,
    sellerPhone: req.user.phone,
    price: Number(price),
    notes: notes || '',
    createdAt: new Date().toISOString(),
  };

  const updated = db.addQuoteToRFQ(req.params.id, quote);
  if (!updated) return res.status(404).json({ error: 'Cotação não encontrada.' });
  res.json(updated);
});

// ==========================================
// 5. ORDERS & MOZAMBIQUE PAYMENT FLOW
// ==========================================

app.post('/api/orders', requireAuth, (req: AuthRequest, res: Response) => {
  const { items, deliveryAddress, paymentMethod = 'mpesa', couponCode } = req.body;

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'O carrinho está vazio.' });
  }

  if (!deliveryAddress || !deliveryAddress.province || !deliveryAddress.street) {
    return res.status(400).json({ error: 'Informe a província, cidade e morada de entrega em Moçambique.' });
  }

  // Calculate items subtotal and validate MOQ and stock
  let subtotal = 0;
  const verifiedItems: OrderItem[] = [];

  for (const item of items) {
    const prod = db.getProductById(item.productId);
    if (!prod) {
      return res.status(400).json({ error: `O produto "${item.title}" já não está disponível.` });
    }

    if (item.quantity < prod.moq) {
      return res.status(400).json({
        error: `O produto "${prod.title}" exige uma quantidade mínima de ${prod.moq} ${prod.unitType}(s).`,
      });
    }

    // Check wholesale tier pricing
    let finalUnitPrice = prod.price;
    if (prod.wholesalePrice && prod.wholesaleMinQty && item.quantity >= prod.wholesaleMinQty) {
      finalUnitPrice = prod.wholesalePrice;
    }

    subtotal += finalUnitPrice * item.quantity;
    verifiedItems.push({
      productId: prod.id,
      title: prod.title,
      price: finalUnitPrice,
      quantity: item.quantity,
      unitType: prod.unitType,
      sellerId: prod.sellerId,
      sellerName: prod.sellerName,
      image: prod.images[0] || '',
    });
  }

  // Delivery fee calculation based on province
  let deliveryFee = 250;
  if (deliveryAddress.province.includes('Maputo Cidade') || deliveryAddress.province.includes('Maputo Província')) {
    deliveryFee = 200;
  } else if (deliveryAddress.province.includes('Gaza') || deliveryAddress.province.includes('Inhambane')) {
    deliveryFee = 450;
  } else if (deliveryAddress.province.includes('Sofala') || deliveryAddress.province.includes('Manica') || deliveryAddress.province.includes('Tete')) {
    deliveryFee = 600;
  } else {
    // Norte (Nampula, Zambezia, Cabo Delgado, Niassa)
    deliveryFee = 750;
  }

  // Coupon discount calculation
  let discount = 0;
  if (couponCode) {
    const coupon = db.findCoupon(couponCode);
    if (coupon && subtotal >= coupon.minOrderAmount) {
      if (coupon.discountPercent) {
        discount = Math.round((subtotal * coupon.discountPercent) / 100);
      } else if (coupon.discountFixed) {
        discount = coupon.discountFixed;
      }
    }
  }

  const total = Math.max(0, subtotal - discount + deliveryFee);
  const settings = db.getSettings();
  const commissionRate = settings.commissionRatePercent / 100;
  const commissionAmount = Math.round(subtotal * commissionRate);
  const sellerPayout = subtotal - commissionAmount;

  const orderNumber = `MOZ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const newOrder: Order = {
    id: 'ord_' + Date.now(),
    orderNumber,
    buyerId: req.user.id,
    buyerName: req.user.name,
    buyerPhone: req.user.phone,
    deliveryAddress,
    items: verifiedItems,
    subtotal,
    discount,
    deliveryFee,
    total,
    commissionRate,
    commissionAmount,
    sellerPayout,
    status: 'aguardando_pagamento',
    paymentMethod,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.addOrder(newOrder);
  db.addAuditLog('PEDIDO_CRIADO', `Pedido #${orderNumber} criado por ${req.user.name}. Total: ${total} MTn`, req.user.phone);

  res.json(newOrder);
});

app.get('/api/orders', requireAuth, (req: AuthRequest, res: Response) => {
  const all = db.getOrders();
  if (req.user.role === 'admin') {
    return res.json(all);
  }
  // Buyer sees their orders; Seller sees orders containing their products
  const userOrders = all.filter((o) => {
    if (o.buyerId === req.user.id) return true;
    return o.items.some((i) => i.sellerId === req.user.id);
  });
  res.json(userOrders);
});

app.get('/api/orders/:id', requireAuth, (req: AuthRequest, res: Response) => {
  const order = db.getOrderById(req.params.id);
  if (!order) return res.status(404).json({ error: 'Pedido não encontrado.' });

  const isOwner = order.buyerId === req.user.id;
  const isSeller = order.items.some((i) => i.sellerId === req.user.id);
  const isAdmin = req.user.role === 'admin';

  if (!isOwner && !isSeller && !isAdmin) {
    return res.status(403).json({ error: 'Permissão negada para consultar este pedido.' });
  }

  res.json(order);
});

// Buyer submits payment transaction reference (e.g. M-Pesa ID "CI248X99K")
app.post('/api/orders/:id/payment', requireAuth, (req: AuthRequest, res: Response) => {
  const { paymentReference, paymentNote } = req.body;
  if (!paymentReference) {
    return res.status(400).json({ error: 'Informe o ID ou Referência da transação M-Pesa ou e-Mola.' });
  }

  const order = db.getOrderById(req.params.id);
  if (!order) return res.status(404).json({ error: 'Pedido não encontrado.' });
  if (order.buyerId !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Permissão negada.' });
  }

  const updated = db.updateOrder(req.params.id, {
    paymentReference: paymentReference.trim().toUpperCase(),
    paymentNote: paymentNote ? paymentNote.trim() : undefined,
    status: 'pagamento_sob_verificacao',
  });

  db.addAuditLog(
    'PAGAMENTO_INFORMADO',
    `Comprovativo submetido para Pedido #${order.orderNumber}. Ref: ${paymentReference}`,
    req.user.phone
  );

  res.json(updated);
});

// Admin approves or rejects M-Pesa/e-Mola manual payment
app.post('/api/admin/verify-payment', requireAdmin, (req: AuthRequest, res: Response) => {
  const { orderId, approved, reason } = req.body;
  const order = db.getOrderById(orderId);
  if (!order) return res.status(404).json({ error: 'Pedido não encontrado.' });

  if (approved) {
    const updated = db.updateOrder(orderId, {
      status: 'pago',
      verifiedBy: req.user.id,
      verifiedAt: new Date().toISOString(),
    });
    db.addAuditLog('PAGAMENTO_APROVADO', `Pagamento do Pedido #${order.orderNumber} verificado e aprovado por Admin.`, req.user.phone);
    return res.json({ success: true, order: updated });
  } else {
    const updated = db.updateOrder(orderId, {
      status: 'aguardando_pagamento',
      paymentNote: `Rejeitado: ${reason || 'Referência inválida ou não recebida.'}`,
    });
    db.addAuditLog('PAGAMENTO_REJEITADO', `Pagamento do Pedido #${order.orderNumber} rejeitado por Admin: ${reason}`, req.user.phone);
    return res.json({ success: true, order: updated });
  }
});

// Order status transitions (Seller / Admin)
app.patch('/api/orders/:id/status', requireAuth, (req: AuthRequest, res: Response) => {
  const { status } = req.body;
  const order = db.getOrderById(req.params.id);
  if (!order) return res.status(404).json({ error: 'Pedido não encontrado.' });

  const isSeller = order.items.some((i) => i.sellerId === req.user.id);
  const isAdmin = req.user.role === 'admin';

  if (!isSeller && !isAdmin) {
    return res.status(403).json({ error: 'Permissão negada.' });
  }

  const updated = db.updateOrder(req.params.id, { status });
  db.addAuditLog('ESTADO_PEDIDO_ATUALIZADO', `Pedido #${order.orderNumber} atualizado para "${status}".`, req.user.phone);

  res.json(updated);
});

// ==========================================
// 6. MESSAGING (Comunicação Comprador / Vendedor)
// ==========================================

app.get('/api/messages', requireAuth, (req: AuthRequest, res: Response) => {
  const userMessages = db.getMessages(req.user.id);
  res.json(userMessages);
});

app.post('/api/messages', requireAuth, (req: AuthRequest, res: Response) => {
  const { receiverId, receiverName, content, referenceType, referenceId, referenceTitle } = req.body;

  if (!receiverId || !content) {
    return res.status(400).json({ error: 'Destinatário e mensagem são obrigatórios.' });
  }

  // Create or reuse deterministic thread ID
  const parts = [req.user.id, receiverId].sort();
  const threadId = `th_${parts[0]}_${parts[1]}${referenceId ? '_' + referenceId : ''}`;

  const message: MessageItem = {
    id: 'msg_' + Date.now(),
    threadId,
    senderId: req.user.id,
    senderName: req.user.businessName || req.user.name,
    receiverId,
    receiverName: receiverName || 'Utilizador',
    content: content.trim(),
    referenceType,
    referenceId,
    referenceTitle,
    isRead: false,
    createdAt: new Date().toISOString(),
  };

  db.addMessage(message);
  res.json(message);
});

// ==========================================
// 7. COUPONS API
// ==========================================

app.post('/api/coupons/validate', (req: Request, res: Response) => {
  const { code, orderAmount = 0 } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'Insira o código do cupom.' });
  }

  const coupon = db.findCoupon(code);
  if (!coupon) {
    return res.status(404).json({ error: 'Cupom inválido ou expirado.' });
  }

  if (orderAmount < coupon.minOrderAmount) {
    return res.status(400).json({
      error: `Este cupom exige um valor mínimo de compra de ${coupon.minOrderAmount.toLocaleString('pt-MZ')} MTn.`,
    });
  }

  let discount = 0;
  if (coupon.discountPercent) {
    discount = Math.round((orderAmount * coupon.discountPercent) / 100);
  } else if (coupon.discountFixed) {
    discount = coupon.discountFixed;
  }

  res.json({
    valid: true,
    code: coupon.code,
    description: coupon.description,
    discount,
  });
});

// ==========================================
// 8. ADMIN DASHBOARD & SETTINGS
// ==========================================

app.get('/api/admin/stats', requireAdmin, (req: AuthRequest, res: Response) => {
  const schema = db.getSchema();
  const totalOrders = schema.orders.length;
  const totalGMV = schema.orders.reduce((acc, o) => acc + (o.status !== 'cancelado' ? o.total : 0), 0);
  const totalCommission = schema.orders.reduce((acc, o) => acc + (o.status === 'pago' || o.status === 'concluido' ? o.commissionAmount : 0), 0);
  const pendingPayments = schema.orders.filter((o) => o.status === 'pagamento_sob_verificacao').length;
  const pendingModeration = schema.products.filter((p) => p.status === 'sob_revisao').length;

  res.json({
    totalUsers: schema.users.length,
    totalProducts: schema.products.length,
    totalServices: schema.services.length,
    totalOrders,
    totalGMV,
    totalCommission,
    pendingPayments,
    pendingModeration,
    openRFQs: schema.rfqs.filter((r) => r.status === 'aberto').length,
  });
});

app.get('/api/admin/settings', requireAdmin, (req: AuthRequest, res: Response) => {
  res.json(db.getSettings());
});

app.post('/api/admin/settings', requireAdmin, (req: AuthRequest, res: Response) => {
  const updated = db.updateSettings(req.body);
  db.addAuditLog('CONFIGURACOES_ATUALIZADAS', 'Definições da plataforma atualizadas por administrador.', req.user.phone);
  res.json(updated);
});

app.get('/api/admin/audit-logs', requireAdmin, (req: AuthRequest, res: Response) => {
  res.json(db.getAuditLogs());
});

// Public payment info endpoint (so checkout can show official M-Pesa & e-Mola instructions)
app.get('/api/payment-info', (req: Request, res: Response) => {
  const s = db.getSettings();
  res.json({
    mpesaNumber: s.mpesaNumber,
    mpesaAccountName: s.mpesaAccountName,
    emolaNumber: s.emolaNumber,
    emolaAccountName: s.emolaAccountName,
    supportPhone: s.supportPhone,
    supportWhatsapp: s.supportWhatsapp,
  });
});

// ==========================================
// 9. AI SMART SEARCH ASSISTANT
// ==========================================

app.post('/api/ai/smart-search', async (req: Request, res: Response) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ error: 'Query necessária.' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    // Fallback: smart keyword matching
    const q = query.toLowerCase();
    const products = db.getProducts().filter(
      (p) =>
        p.status === 'ativo' &&
        (p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.sellerCity.toLowerCase().includes(q))
    );
    return res.json({
      intent: 'busca_padrao',
      suggestedQuery: query,
      matchingProducts: products,
      explanation: `Resultados encontrados para "${query}" no catálogo de Moçambique.`,
    });
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `O utilizador do marketplace moçambicano Moz Fácil Fal pesquisou: "${query}".
Categorias do marketplace: Construção & Ferragens, Agricultura & Alimentos, Tecnologia & Eletrónica, Serviços Técnicos & Reparação, Transporte & Cargas, Moda, Tecidos & Capulanas.
Províncias de Moçambique: Maputo, Gaza, Inhambane, Sofala, Manica, Tete, Zambézia, Nampula, Cabo Delgado, Niassa.

Responda em formato JSON puro:
{
  "category": "nome da categoria mais provável ou vazio",
  "province": "nome da província se mencionada ou vazio",
  "keywords": ["palavras-chave", "relevantes"],
  "summary": "1 frase curta e amigável em português explicando o que foi interpretado"
}`,
    });

    const text = response.text || '';
    const cleanJson = text.replace(/```json/g, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(cleanJson);

    // Filter products based on extracted intent
    let matched = db.getProducts().filter((p) => p.status === 'ativo');
    if (parsed.category) {
      const catMatch = matched.filter((p) => p.category.toLowerCase().includes(parsed.category.toLowerCase()));
      if (catMatch.length > 0) matched = catMatch;
    }
    if (parsed.province) {
      const provMatch = matched.filter((p) => p.sellerCity.toLowerCase().includes(parsed.province.toLowerCase()));
      if (provMatch.length > 0) matched = provMatch;
    }

    res.json({
      intent: 'busca_ia_otimizada',
      parsed,
      matchingProducts: matched,
      explanation: parsed.summary,
    });
  } catch (err) {
    // Graceful fallback
    const q = query.toLowerCase();
    const products = db.getProducts().filter((p) => p.status === 'ativo' && p.title.toLowerCase().includes(q));
    res.json({
      intent: 'busca_padrao',
      suggestedQuery: query,
      matchingProducts: products,
      explanation: `Resultados para "${query}".`,
    });
  }
});

// ==========================================
// 10. FRONTEND INTEGRATION (Vite / Static)
// ==========================================

async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`🇲🇿 Moz Fácil Fal rodando na porta ${PORT}`);
  });
}

startServer();
