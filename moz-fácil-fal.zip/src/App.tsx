/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { Footer } from './components/Footer.tsx';
import { MobileBottomNav } from './components/MobileBottomNav.tsx';
import { HomeView } from './components/HomeView.tsx';
import { ProductCatalogView } from './components/ProductCatalogView.tsx';
import { ServicesDirectory } from './components/ServicesDirectory.tsx';
import { RFQDirectory } from './components/RFQDirectory.tsx';
import { ProvincesDirectory } from './components/ProvincesDirectory.tsx';
import { OrderHistoryView } from './components/OrderHistoryView.tsx';
import { FavoritesView } from './components/FavoritesView.tsx';
import { VendorDashboard } from './components/VendorDashboard.tsx';
import { AdminPanel } from './components/AdminPanel.tsx';

// Modals
import { AuthModal } from './components/AuthModal.tsx';
import { ProductDetailModal } from './components/ProductDetailModal.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { OrderPaymentModal } from './components/OrderPaymentModal.tsx';
import { RFQModal } from './components/RFQModal.tsx';
import { MessagesModal } from './components/MessagesModal.tsx';
import { AISearchModal } from './components/AISearchModal.tsx';
import { NewServiceModal } from './components/NewServiceModal.tsx';

import { api, CartItem } from './services/api.ts';
import { Product, ServiceItem, RFQItem, Order, User } from './types/index.ts';

export default function App() {
  // Navigation & Filtering
  const [activeTab, setActiveTab] = useState<string>('inicio');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');

  // Core Data
  const [products, setProducts] = useState<Product[]>([]);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [rfqs, setRfqs] = useState<RFQItem[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [user, setUser] = useState<User | null>(null);

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authInitialTab, setAuthInitialTab] = useState<'login' | 'register'>('login');
  const [cartOpen, setCartOpen] = useState(false);
  const [rfqModalOpen, setRfqModalOpen] = useState(false);
  const [messagesModalOpen, setMessagesModalOpen] = useState(false);
  const [aiSearchModalOpen, setAiSearchModalOpen] = useState(false);
  const [newServiceModalOpen, setNewServiceModalOpen] = useState(false);

  // Active target for modals
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activePaymentOrder, setActivePaymentOrder] = useState<Order | null>(null);
  const [chatTarget, setChatTarget] = useState<{ id: string; name: string } | null>(null);
  const [chatReference, setChatReference] = useState<{ type: string; id: string; title: string } | null>(null);

  // Initial load
  useEffect(() => {
    // Load local storage states
    setCart(api.getCart());
    setFavorites(api.getFavorites());

    // Check user session
    api.getMe().then((u) => {
      if (u) setUser(u);
    });

    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [prods, servs, rfqList] = await Promise.all([
        api.getProducts({ onlyActive: 'false' }),
        api.getServices(),
        api.getRFQs(),
      ]);
      setProducts(prods);
      setServices(servs);
      setRfqs(rfqList);
    } catch (e) {
      console.error('Erro ao carregar dados:', e);
    }
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity: number = product.moq) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      let updated: CartItem[];
      if (existing) {
        updated = prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        updated = [...prev, { product, quantity: Math.max(product.moq, quantity) }];
      }
      api.saveCart(updated);
      return updated;
    });
    setCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    setCart((prev) => {
      const updated = prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      );
      api.saveCart(updated);
      return updated;
    });
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => {
      const updated = prev.filter((item) => item.product.id !== productId);
      api.saveCart(updated);
      return updated;
    });
  };

  // Favorites
  const handleToggleFavorite = (productId: string) => {
    const updated = api.toggleFavorite(productId);
    setFavorites([...updated]);
  };

  // Contact / Message
  const handleContactSeller = (product: Product) => {
    setChatTarget({ id: product.sellerId, name: product.sellerName });
    setChatReference({ type: 'product', id: product.id, title: product.title });
    setSelectedProduct(null);
    setMessagesModalOpen(true);
  };

  const handleContactServiceProvider = (service: ServiceItem) => {
    setChatTarget({ id: service.providerId, name: service.providerName });
    setChatReference({ type: 'service', id: service.id, title: service.title });
    setMessagesModalOpen(true);
  };

  // Order created -> prompt payment
  const handleOrderCreated = (order: Order) => {
    setCart([]);
    api.saveCart([]);
    setActivePaymentOrder(order);
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
    setActiveTab('inicio');
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 pb-16 md:pb-0">
      {/* Header */}
      <Header
        user={user}
        cartCount={cart.reduce((sum, i) => sum + i.quantity, 0)}
        favoritesCount={favorites.length}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        onOpenAuth={(tab) => {
          setAuthInitialTab(tab || 'login');
          setAuthModalOpen(true);
        }}
        onOpenCart={() => setCartOpen(true)}
        onOpenRFQ={() => setRfqModalOpen(true)}
        onOpenMessages={() => {
          setChatTarget(null);
          setChatReference(null);
          setMessagesModalOpen(true);
        }}
        onLogout={handleLogout}
        onAiSearch={() => setAiSearchModalOpen(true)}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {activeTab === 'inicio' && (
          <HomeView
            products={products}
            services={services}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onAddToCart={handleAddToCart}
            onViewProductDetails={(p) => setSelectedProduct(p)}
            onViewServiceDetails={(s) => handleContactServiceProvider(s)}
            onOpenRFQ={() => setRfqModalOpen(true)}
            onSelectCategory={(cat) => {
              setSelectedCategory(cat);
              setActiveTab('produtos');
            }}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'produtos' && (
          <ProductCatalogView
            products={products}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onAddToCart={handleAddToCart}
            onViewDetails={(p) => setSelectedProduct(p)}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}

        {activeTab === 'servicos' && (
          <ServicesDirectory
            services={services}
            user={user}
            onContactProvider={handleContactServiceProvider}
            onOpenNewService={() => setNewServiceModalOpen(true)}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {activeTab === 'rfqs' && (
          <RFQDirectory
            rfqs={rfqs}
            user={user}
            onOpenNewRFQ={() => setRfqModalOpen(true)}
            onRefreshData={loadData}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {activeTab === 'vendedores-locais' && (
          <ProvincesDirectory
            onSelectProvince={(prov) => {
              setSearchQuery(prov);
              setActiveTab('produtos');
            }}
          />
        )}

        {activeTab === 'fornecedores' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
            <div className="mb-8">
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                Diretório de Empresas & Fabricantes
              </span>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-2">
                Fornecedores & Fabricantes Verificados em Moçambique
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
                Negocie diretamente com importadores, fábricas e distribuidores industriais com preços de atacado e faturas com NUIT.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600 font-bold flex items-center justify-center text-lg mb-3">
                    AG
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">
                    AgroMoçambique Export & Distribuição
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Nampula Cidade · Corredor de Nacala
                  </p>
                  <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                    Especialista em castanha de caju bruta, gergelim branco e cereais não-OGM para grandes distribuidores e revenda.
                  </p>
                </div>
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-emerald-700 font-semibold">
                    100% Verificado
                  </span>
                  <button
                    onClick={() => {
                      setSearchQuery('AgroMoçambique');
                      setActiveTab('produtos');
                    }}
                    className="text-xs font-semibold text-amber-600 hover:underline cursor-pointer"
                  >
                    Ver Produtos →
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-600 font-bold flex items-center justify-center text-lg mb-3">
                    ES
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">
                    ElectroSolar & Tech Maputo
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Maputo Cidade · Av. 24 de Julho
                  </p>
                  <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                    Importação direta de estações de energia solar, baterias LiFePO4, inversores e telemóveis industriais blindados com garantia oficial.
                  </p>
                </div>
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-emerald-700 font-semibold">
                    Garantia 12 Meses
                  </span>
                  <button
                    onClick={() => {
                      setSearchQuery('ElectroSolar');
                      setActiveTab('produtos');
                    }}
                    className="text-xs font-semibold text-amber-600 hover:underline cursor-pointer"
                  >
                    Ver Produtos →
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 font-bold flex items-center justify-center text-lg mb-3">
                    CF
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">
                    Construções & Ferragens do Centro
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Beira · Zona Portuária & Munhava
                  </p>
                  <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                    Armazém atacadista de cimento estrutural 42.5N, cerâmicas porcelanato, varões de aço e tubagens com entrega direta em estaleiro.
                  </p>
                </div>
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-emerald-700 font-semibold">
                    Entrega em Camião
                  </span>
                  <button
                    onClick={() => {
                      setSearchQuery('Construções & Ferragens');
                      setActiveTab('produtos');
                    }}
                    className="text-xs font-semibold text-amber-600 hover:underline cursor-pointer"
                  >
                    Ver Produtos →
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'pedidos' && (
          <OrderHistoryView
            user={user}
            onOpenPaymentModal={(ord) => setActivePaymentOrder(ord)}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {activeTab === 'favoritos' && (
          <FavoritesView
            products={products}
            favoriteIds={favorites}
            onToggleFavorite={handleToggleFavorite}
            onAddToCart={handleAddToCart}
            onViewDetails={(p) => setSelectedProduct(p)}
            onExploreCatalog={() => setActiveTab('produtos')}
          />
        )}

        {activeTab === 'vendedor' && (
          <>
            {user ? (
              <VendorDashboard
                user={user}
                onRefreshData={loadData}
                onOpenNewService={() => setNewServiceModalOpen(true)}
              />
            ) : (
              <div className="max-w-2xl mx-auto px-4 py-16 text-center">
                <h2 className="text-2xl font-bold text-slate-900 font-display mb-2">
                  Comece a Vender no Moz Fácil Fal
                </h2>
                <p className="text-xs text-slate-600 mb-6 leading-relaxed">
                  Conecte a sua empresa, quinta agrícola ou loja a milhares de compradores em Maputo, Beira, Nampula e todo Moçambique. Pagamentos seguros via M-Pesa e e-Mola.
                </p>
                <button
                  onClick={() => {
                    setAuthInitialTab('register');
                    setAuthModalOpen(true);
                  }}
                  className="py-3 px-6 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                >
                  Criar Conta de Vendedor
                </button>
              </div>
            )}
          </>
        )}

        {activeTab === 'admin' && (
          <>
            {user?.role === 'admin' ? (
              <AdminPanel user={user} onRefreshData={loadData} />
            ) : (
              <div className="max-w-md mx-auto px-4 py-16 text-center text-xs text-slate-500">
                Acesso restrito à administração da plataforma.
              </div>
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenRFQ={() => setRfqModalOpen(true)}
        onOpenCategory={(cat) => {
          setSelectedCategory(cat);
          setActiveTab('produtos');
        }}
      />

      {/* Mobile Bottom Nav */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cart.reduce((sum, i) => sum + i.quantity, 0)}
        user={user}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenCart={() => setCartOpen(true)}
        onOpenMessages={() => {
          setChatTarget(null);
          setChatReference(null);
          setMessagesModalOpen(true);
        }}
      />

      {/* Modals */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialTab={authInitialTab}
        onSuccess={(newUser) => setUser(newUser)}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        isFavorite={selectedProduct ? favorites.includes(selectedProduct.id) : false}
        onToggleFavorite={handleToggleFavorite}
        onAddToCart={handleAddToCart}
        onContactSeller={handleContactSeller}
      />

      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        user={user}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onOrderCreated={handleOrderCreated}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      <OrderPaymentModal
        order={activePaymentOrder}
        onClose={() => setActivePaymentOrder(null)}
        onPaymentSubmitted={(updated) => {
          setActivePaymentOrder(updated);
          loadData();
        }}
      />

      <RFQModal
        isOpen={rfqModalOpen}
        onClose={() => setRfqModalOpen(false)}
        user={user}
        onRFQCreated={() => {
          loadData();
          setActiveTab('rfqs');
        }}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      <MessagesModal
        isOpen={messagesModalOpen}
        onClose={() => setMessagesModalOpen(false)}
        user={user}
        targetUser={chatTarget}
        reference={chatReference}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      <AISearchModal
        isOpen={aiSearchModalOpen}
        onClose={() => setAiSearchModalOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      <NewServiceModal
        isOpen={newServiceModalOpen}
        onClose={() => setNewServiceModalOpen(false)}
        user={user}
        onServiceCreated={() => {
          loadData();
          setActiveTab('servicos');
        }}
        onOpenAuth={() => setAuthModalOpen(true)}
      />
    </div>
  );
}
