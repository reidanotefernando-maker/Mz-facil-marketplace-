import React, { useState } from 'react';
import {
  X,
  Heart,
  ShoppingCart,
  MapPin,
  ShieldCheck,
  Truck,
  Phone,
  MessageSquare,
  Package,
  Check,
  Plus,
  Minus,
} from 'lucide-react';
import { Product } from '../types/index.ts';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onContactSeller: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  isFavorite,
  onToggleFavorite,
  onAddToCart,
  onContactSeller,
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState<number>(product.moq || 1);
  const [addedNotice, setAddedNotice] = useState(false);

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  // Determine active unit price based on wholesale tiers
  const isWholesaleActive =
    product.wholesalePrice &&
    product.wholesaleMinQty &&
    quantity >= product.wholesaleMinQty;

  const currentUnitPrice = isWholesaleActive
    ? product.wholesalePrice!
    : product.price;

  const totalPrice = currentUnitPrice * quantity;

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200 my-auto">
        {/* Header Bar */}
        <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>{product.category}</span>
            <span>·</span>
            <span>{product.subcategory || 'Artigo'}</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Image */}
          <div>
            <div className="aspect-4/3 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 relative mb-4">
              <img
                src={product.images[0] || ''}
                alt={product.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={() => onToggleFavorite(product.id)}
                className={`absolute top-3 right-3 p-2 rounded-full shadow-md transition-colors cursor-pointer ${
                  isFavorite
                    ? 'bg-rose-50 text-rose-500'
                    : 'bg-white/90 text-slate-500 hover:text-rose-500'
                }`}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-rose-500' : ''}`} />
              </button>
            </div>

            {/* Seller profile card */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5 font-semibold text-slate-900 text-sm">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>{product.sellerName}</span>
                  </div>
                  <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-amber-500" />
                    {product.sellerCity} · Moçambique
                  </p>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                  Verificado
                </span>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => onContactSeller(product)}
                  className="flex-1 py-2 px-3 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
                  Contactar Fornecedor
                </button>
                <a
                  href={`tel:${product.sellerPhone}`}
                  className="p-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition-colors cursor-pointer"
                  title="Ligar para o Vendedor"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Pricing & Purchase Details */}
          <div className="flex flex-col justify-between">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 leading-tight mb-3">
                {product.title}
              </h1>

              {/* Wholesale Pricing Table / Box */}
              <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200 mb-5">
                <div className="grid grid-cols-2 gap-4 divide-x divide-amber-200">
                  <div>
                    <span className="text-[11px] font-medium text-amber-800 block">
                      Preço Unitário (Mín. {product.moq} {product.unitType})
                    </span>
                    <span className="text-xl font-extrabold text-slate-900 font-mono tabular-nums">
                      {formatPrice(product.price)}
                    </span>
                    <span className="text-xs text-slate-500 block">por {product.unitType}</span>
                  </div>

                  {product.wholesalePrice && product.wholesaleMinQty && (
                    <div className="pl-4">
                      <span className="text-[11px] font-medium text-emerald-800 block">
                        Preço Atacado (≥ {product.wholesaleMinQty} {product.unitType}s)
                      </span>
                      <span className="text-xl font-extrabold text-emerald-700 font-mono tabular-nums">
                        {formatPrice(product.wholesalePrice)}
                      </span>
                      <span className="text-xs text-slate-500 block">por {product.unitType}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Especificações & Descrição
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                  {product.description}
                </p>
              </div>

              {/* Logistics & Delivery */}
              <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs mb-6">
                <Truck className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-800">Condições de Entrega:</span>
                  <p className="text-slate-500 mt-0.5">
                    {product.deliveryInfo || 'Envios disponíveis para Maputo, Beira, Nampula e restantes províncias via parceiros logísticos.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Bottom Purchase Bar */}
            <div className="pt-4 border-t border-slate-200 space-y-4">
              {/* Quantity Stepper with MOQ Check */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-700 block">Quantidade</span>
                  <span className="text-[11px] text-slate-500">
                    Mínimo: {product.moq} {product.unitType}(s) · Stock: {product.stock} {product.unitType}(s)
                  </span>
                </div>

                <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(product.moq, quantity - 1))}
                    disabled={quantity <= product.moq}
                    className="p-2 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <input
                    type="number"
                    min={product.moq}
                    max={product.stock}
                    value={quantity}
                    onChange={(e) => {
                      const val = parseInt(e.target.value) || product.moq;
                      setQuantity(Math.max(product.moq, Math.min(product.stock, val)));
                    }}
                    className="w-14 text-center text-xs font-bold font-mono outline-none py-1"
                  />
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    disabled={quantity >= product.stock}
                    className="p-2 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Subtotal preview */}
              <div className="flex items-center justify-between text-xs font-medium text-slate-600 bg-slate-50 p-2.5 rounded-lg">
                <span>Subtotal da Encomenda:</span>
                <span className="text-base font-extrabold text-slate-900 font-mono tabular-nums">
                  {formatPrice(totalPrice)}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className="flex-1 py-3 px-4 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
                >
                  {addedNotice ? (
                    <>
                      <Check className="w-4 h-4" />
                      Adicionado ao Carrinho!
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4" />
                      Adicionar ao Carrinho
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => onContactSeller(product)}
                  className="py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  Pedir Cotação
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
