import React, { useState } from 'react';
import { Filter, SlidersHorizontal, ArrowUpDown, Search, Package, MapPin, X } from 'lucide-react';
import { Product } from '../types/index.ts';
import { ProductCard } from './ProductCard.tsx';

interface ProductCatalogViewProps {
  products: Product[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onViewDetails: (product: Product) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const CATEGORIES = [
  'Todas',
  'Agricultura & Alimentos',
  'Construção & Ferragens',
  'Tecnologia & Eletrónica',
  'Serviços Técnicos & Reparação',
  'Transporte & Cargas',
  'Moda, Tecidos & Capulanas',
  'Eletrodomésticos & Casa',
];

const PROVINCES = [
  'Todas as Províncias',
  'Maputo Cidade',
  'Maputo Província',
  'Gaza',
  'Inhambane',
  'Sofala',
  'Manica',
  'Tete',
  'Zambézia',
  'Nampula',
  'Cabo Delgado',
  'Niassa',
];

export const ProductCatalogView: React.FC<ProductCatalogViewProps> = ({
  products,
  favorites,
  onToggleFavorite,
  onAddToCart,
  onViewDetails,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
}) => {
  const [selectedProvince, setSelectedProvince] = useState('Todas as Províncias');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'price_asc' | 'price_desc' | 'rating'>('newest');
  const [showMobileFilter, setShowMobileFilter] = useState(false);

  // Filter products locally or through query
  let filtered = products.filter((p) => {
    // Status filter
    if (p.status !== 'ativo') return false;

    // Category
    if (
      selectedCategory &&
      selectedCategory !== 'Todas' &&
      !p.category.toLowerCase().includes(selectedCategory.toLowerCase())
    ) {
      return false;
    }

    // Province / City
    if (
      selectedProvince &&
      selectedProvince !== 'Todas as Províncias' &&
      !p.sellerCity.toLowerCase().includes(selectedProvince.toLowerCase())
    ) {
      return false;
    }

    // Min price
    if (minPrice && p.price < Number(minPrice)) {
      return false;
    }

    // Max price
    if (maxPrice && p.price > Number(maxPrice)) {
      return false;
    }

    // Search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match =
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.sellerName.toLowerCase().includes(q) ||
        p.sellerCity.toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });

  // Sorting
  if (sortBy === 'price_asc') {
    filtered.sort((a, b) => a.price - b.price);
  } else if (sortBy === 'price_desc') {
    filtered.sort((a, b) => b.price - a.price);
  } else if (sortBy === 'rating') {
    filtered.sort((a, b) => b.rating - a.rating);
  } else {
    filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  const resetFilters = () => {
    setSelectedCategory('Todas');
    setSelectedProvince('Todas as Províncias');
    setMinPrice('');
    setMaxPrice('');
    setSearchQuery('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Top Banner & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
            Catálogo de Produtos & Fornecedores
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {filtered.length} artigos disponíveis em Moçambique
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Mobile Filter toggle */}
          <button
            onClick={() => setShowMobileFilter(!showMobileFilter)}
            className="md:hidden py-2 px-3 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filtros
          </button>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 hidden sm:inline">Ordenar por:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="py-2 px-3 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 outline-none cursor-pointer"
            >
              <option value="newest">Mais Recentes</option>
              <option value="price_asc">Menor Preço (MTn)</option>
              <option value="price_desc">Maior Preço (MTn)</option>
              <option value="rating">Melhor Avaliação</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 items-start">
        {/* Filters Sidebar */}
        <div
          className={`md:block ${
            showMobileFilter ? 'block mb-6' : 'hidden'
          } bg-white rounded-xl border border-slate-200 p-5 space-y-6 shadow-xs`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <span className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-amber-500" />
              Filtrar Produtos
            </span>
            <button
              onClick={resetFilters}
              className="text-[11px] text-amber-600 hover:underline cursor-pointer"
            >
              Limpar Tudo
            </button>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-semibold text-slate-800 mb-2">Categorias</h4>
            <div className="space-y-1">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full text-left py-1.5 px-2 rounded-lg text-xs transition-colors cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-amber-500 text-white font-semibold'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Location filter */}
          <div>
            <h4 className="text-xs font-semibold text-slate-800 mb-2">
              Província / Região
            </h4>
            <select
              value={selectedProvince}
              onChange={(e) => setSelectedProvince(e.target.value)}
              className="w-full py-2 px-2.5 border border-slate-300 rounded-lg text-xs bg-white outline-none"
            >
              {PROVINCES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          {/* Price Range */}
          <div>
            <h4 className="text-xs font-semibold text-slate-800 mb-2">
              Faixa de Preço (MTn)
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <input
                type="number"
                placeholder="Mínimo"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="py-1.5 px-2 border border-slate-300 rounded font-mono outline-none"
              />
              <input
                type="number"
                placeholder="Máximo"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="py-1.5 px-2 border border-slate-300 rounded font-mono outline-none"
              />
            </div>
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="md:col-span-3">
          {filtered.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8">
              <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-semibold text-slate-800 text-base">
                Nenhum produto encontrado
              </h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Tente ajustar os filtros ou pesquisar com outros termos.
              </p>
              <button
                onClick={resetFilters}
                className="py-2 px-4 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-lg cursor-pointer"
              >
                Limpar Filtros
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((prod) => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  isFavorite={favorites.includes(prod.id)}
                  onToggleFavorite={onToggleFavorite}
                  onAddToCart={onAddToCart}
                  onViewDetails={onViewDetails}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
