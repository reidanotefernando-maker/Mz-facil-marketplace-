import React, { useState } from 'react';
import { X, Wrench, AlertCircle, CheckCircle } from 'lucide-react';
import { api } from '../services/api.ts';
import { ServiceItem, User } from '../types/index.ts';

interface NewServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onServiceCreated: (service: ServiceItem) => void;
  onOpenAuth: () => void;
}

const SERVICE_CATEGORIES = [
  'Reparação & Assistência Técnica',
  'Eletricistas & Canalizadores',
  'Transporte & Cargas',
  'Construção Civil & Obras',
  'Informática & Design Gráfico',
  'Limpeza & Serviços Gerais',
  'Consultoria & Explicações',
];

export const NewServiceModal: React.FC<NewServiceModalProps> = ({
  isOpen,
  onClose,
  user,
  onServiceCreated,
  onOpenAuth,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(SERVICE_CATEGORIES[0]);
  const [price, setPrice] = useState('');
  const [priceUnit, setPriceUnit] = useState('por serviço');
  const [isNegotiable, setIsNegotiable] = useState(true);
  const [description, setDescription] = useState('');
  const [availability, setAvailability] = useState('Segunda a Sábado, 08h às 18h');
  const [imageUrl, setImageUrl] = useState('/src/assets/images/service_technician_repair_1792475629469.jpg');

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }

    if (!title.trim() || !description.trim()) {
      setError('Por favor preencha o título e a descrição do serviço.');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const created = await api.createService({
        title: title.trim(),
        description: description.trim(),
        category,
        price: Number(price) || 0,
        priceUnit,
        isNegotiable,
        availability,
        images: [imageUrl],
      });

      onServiceCreated(created);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Erro ao publicar serviço.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 my-auto">
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center font-bold text-white text-sm">
              <Wrench className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base font-display">Anunciar Serviço em Moçambique</h3>
              <p className="text-xs text-slate-400">Divulgue as suas competências profissionais</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Título do Serviço
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Instalação Elétrica & Painéis Solares Residencial"
              className="w-full py-2.5 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Categoria</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white"
              >
                {SERVICE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Preço Base (MTn)
              </label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Ex: 1500 (ou 0 se a combinar)"
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Cobrança
              </label>
              <input
                type="text"
                value={priceUnit}
                onChange={(e) => setPriceUnit(e.target.value)}
                placeholder="Ex: por hora, por diagnóstico, por viagem"
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Disponibilidade
              </label>
              <input
                type="text"
                value={availability}
                onChange={(e) => setAvailability(e.target.value)}
                placeholder="Ex: 24h ou Seg-Sex 08h-18h"
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="isNegotiable"
              checked={isNegotiable}
              onChange={(e) => setIsNegotiable(e.target.checked)}
              className="rounded text-amber-500 focus:ring-amber-400"
            />
            <label htmlFor="isNegotiable" className="text-slate-700 font-medium cursor-pointer">
              Preço aberto a negociação e orçamento personalizado
            </label>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Descrição Detalhada do Serviço
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descreva a sua experiência, equipamentos utilizados, garantias oferecidas..."
              rows={4}
              className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer shadow-md"
          >
            {saving ? 'A publicar...' : 'Publicar Serviço no Diretório'}
          </button>
        </form>
      </div>
    </div>
  );
};
