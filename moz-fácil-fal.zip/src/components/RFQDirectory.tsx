import React, { useState } from 'react';
import { Building2, PlusCircle, MapPin, Send, CheckCircle, Clock } from 'lucide-react';
import { RFQItem, User } from '../types/index.ts';
import { api } from '../services/api.ts';

interface RFQDirectoryProps {
  rfqs: RFQItem[];
  user: User | null;
  onOpenNewRFQ: () => void;
  onRefreshData: () => void;
  onOpenAuth: () => void;
}

export const RFQDirectory: React.FC<RFQDirectoryProps> = ({
  rfqs,
  user,
  onOpenNewRFQ,
  onRefreshData,
  onOpenAuth,
}) => {
  const [selectedRFQ, setSelectedRFQ] = useState<RFQItem | null>(null);
  const [quotePrice, setQuotePrice] = useState('');
  const [quoteNotes, setQuoteNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  const handleSendQuote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }
    if (!selectedRFQ || !quotePrice) return;

    setSubmitting(true);
    setFeedback(null);

    try {
      await api.submitQuote(selectedRFQ.id, {
        price: Number(quotePrice),
        notes: quoteNotes.trim(),
      });
      setFeedback('Cotação enviada com sucesso ao comprador!');
      setQuotePrice('');
      setQuoteNotes('');
      setSelectedRFQ(null);
      onRefreshData();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message || 'Erro ao submeter cotação.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Hero */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xl">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-500 text-slate-900">
            RFQ · Mercado Atacadista
          </span>
          <h1 className="text-xl sm:text-2xl font-bold font-display mt-2">
            Central de Cotações & Pedidos de Orçamento
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Compradores publicam o que precisam em Moçambique e recebem propostas diretas de fornecedores e empresas qualificadas.
          </p>
        </div>

        <button
          onClick={onOpenNewRFQ}
          className="py-2.5 px-5 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-md self-start md:self-auto shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          Publicar Minha Cotação (RFQ)
        </button>
      </div>

      {feedback && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs mb-6 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* RFQ List */}
      <div className="space-y-4">
        {rfqs.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8 text-xs text-slate-500">
            Nenhuma solicitação aberta no momento. Seja o primeiro a publicar!
          </div>
        ) : (
          rfqs.map((rfq) => (
            <div
              key={rfq.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-sm">{rfq.title}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                    {rfq.category}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-slate-500">
                  <MapPin className="w-3.5 h-3.5 text-amber-500" />
                  <span>{rfq.city}</span>
                  <span>·</span>
                  <span>Qtd: <strong>{rfq.quantity} un</strong></span>
                  {rfq.targetPrice && (
                    <>
                      <span>·</span>
                      <span>Alvo: <strong>{formatPrice(rfq.targetPrice)}</strong></span>
                    </>
                  )}
                </div>
              </div>

              <div className="py-3 text-xs text-slate-600 leading-relaxed">
                <p>{rfq.description}</p>
                <div className="mt-2 text-[11px] text-slate-400">
                  Publicado por: {rfq.buyerName} ({rfq.buyerPhone}) · {new Date(rfq.createdAt).toLocaleDateString('pt-MZ')}
                </div>
              </div>

              {/* Existing Quotes */}
              {rfq.quotes && rfq.quotes.length > 0 && (
                <div className="pt-2 pb-2 border-t border-slate-100">
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">
                    Propostas Recebidas ({rfq.quotes.length}):
                  </span>
                  <div className="space-y-1.5">
                    {rfq.quotes.map((q) => (
                      <div key={q.id} className="p-2 bg-slate-50 rounded text-xs flex justify-between items-center">
                        <div>
                          <strong className="text-slate-900">{q.sellerName}</strong>
                          <span className="text-slate-400 ml-2">({q.sellerPhone})</span>
                          {q.notes && <p className="text-[11px] text-slate-500 mt-0.5">{q.notes}</p>}
                        </div>
                        <span className="font-mono font-bold text-emerald-700">
                          {formatPrice(q.price)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action: Seller submits quote */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end">
                {selectedRFQ?.id === rfq.id ? (
                  <form onSubmit={handleSendQuote} className="w-full bg-slate-50 p-4 rounded-xl space-y-3 text-xs">
                    <h4 className="font-bold text-slate-900">Enviar Minha Proposta de Preço:</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Preço Cotado por Unidade (MTn)
                        </label>
                        <input
                          type="number"
                          value={quotePrice}
                          onChange={(e) => setQuotePrice(e.target.value)}
                          placeholder="Ex: 790"
                          className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white font-mono"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Notas / Condições de Entrega
                        </label>
                        <input
                          type="text"
                          value={quoteNotes}
                          onChange={(e) => setQuoteNotes(e.target.value)}
                          placeholder="Ex: Entrega em 48h incluída com camião"
                          className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedRFQ(null)}
                        className="py-1.5 px-3 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        disabled={submitting}
                        className="py-1.5 px-4 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <Send className="w-3.5 h-3.5" />
                        {submitting ? 'A enviar...' : 'Confirmar Cotação'}
                      </button>
                    </div>
                  </form>
                ) : (
                  <button
                    onClick={() => {
                      if (!user) onOpenAuth();
                      else setSelectedRFQ(rfq);
                    }}
                    className="py-2 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5 text-amber-400" />
                    Responder com Cotação
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
