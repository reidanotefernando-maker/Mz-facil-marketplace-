import React, { useState, useEffect } from 'react';
import { Package, Clock, ShieldCheck, Truck, CheckCircle2, ChevronRight, AlertCircle } from 'lucide-react';
import { Order, User } from '../types/index.ts';
import { api } from '../services/api.ts';

interface OrderHistoryViewProps {
  user: User | null;
  onOpenPaymentModal: (order: Order) => void;
  onOpenAuth: () => void;
}

export const OrderHistoryView: React.FC<OrderHistoryViewProps> = ({
  user,
  onOpenPaymentModal,
  onOpenAuth,
}) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadOrders();
    }
  }, [user]);

  const loadOrders = async () => {
    setLoading(true);
    try {
      const data = await api.getOrders();
      setOrders(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-900 mb-2 font-display">
          Consulte os seus Pedidos & Compras
        </h2>
        <p className="text-xs text-slate-500 mb-6">
          Inicie sessão com o seu número de telemóvel para acompanhar os envios e pagamentos.
        </p>
        <button
          onClick={onOpenAuth}
          className="py-2.5 px-6 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-xl cursor-pointer"
        >
          Entrar com Telefone
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
            Meus Pedidos & Encomendas
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Histórico completo de compras e transações M-Pesa / e-Mola
          </p>
        </div>
        <button
          onClick={loadOrders}
          className="text-xs font-semibold text-amber-600 hover:text-amber-700 cursor-pointer"
        >
          Atualizar Lista
        </button>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8">
          <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-semibold text-slate-800 text-sm">Ainda não tem pedidos efetuados</h3>
          <p className="text-xs text-slate-500 mt-1">
            Explore o nosso catálogo e aproveite as melhores ofertas de Moçambique.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:border-slate-300 transition-colors"
            >
              {/* Order Card Top Bar */}
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3">
                  <span className="font-bold text-slate-900 font-mono">
                    Pedido #{order.orderNumber}
                  </span>
                  <span className="text-slate-400">·</span>
                  <span className="text-slate-500">
                    {new Date(order.createdAt).toLocaleDateString('pt-MZ')}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-slate-500">
                    Método:{' '}
                    <strong className="uppercase font-semibold text-slate-700">
                      {order.paymentMethod}
                    </strong>
                  </span>
                  <span className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    order.status === 'pago'
                      ? 'bg-emerald-100 text-emerald-800'
                      : order.status === 'pagamento_sob_verificacao'
                      ? 'bg-amber-100 text-amber-800'
                      : order.status === 'enviado'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-slate-200 text-slate-800'
                  }`}>
                    {order.status === 'pagamento_sob_verificacao'
                      ? 'Sob Verificação'
                      : order.status === 'aguardando_pagamento'
                      ? 'Aguardando Pagamento'
                      : order.status}
                  </span>
                </div>
              </div>

              {/* Order Items */}
              <div className="p-4 divide-y divide-slate-100 text-xs">
                {order.items.map((item, idx) => (
                  <div key={idx} className="py-2.5 first:pt-0 last:pb-0 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={item.image || ''}
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded object-cover bg-slate-100 border border-slate-200 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-slate-900 block">
                          {item.title}
                        </span>
                        <span className="text-slate-400 text-[11px]">
                          Vendedor: {item.sellerName}
                        </span>
                      </div>
                    </div>

                    <div className="text-right font-mono tabular-nums">
                      <span className="font-bold text-slate-900 block">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                      <span className="text-slate-400 text-[11px]">
                        {item.quantity} {item.unitType}(s) × {formatPrice(item.price)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Card Footer */}
              <div className="p-4 bg-slate-50/50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="text-slate-500">Entrega: </span>
                  <span className="text-slate-700 font-medium">
                    {order.deliveryAddress.province}, {order.deliveryAddress.city} — {order.deliveryAddress.street}
                  </span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className="text-slate-500 block text-[11px]">Valor Total:</span>
                    <span className="text-base font-extrabold font-mono text-slate-900 tabular-nums">
                      {formatPrice(order.total)}
                    </span>
                  </div>

                  {order.status !== 'pago' && order.status !== 'concluido' && (
                    <button
                      onClick={() => onOpenPaymentModal(order)}
                      className="py-2 px-3.5 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-lg transition-colors cursor-pointer shadow-xs shrink-0"
                    >
                      {order.status === 'pagamento_sob_verificacao'
                        ? 'Ver Comprovativo'
                        : 'Pagar com M-Pesa / e-Mola'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
