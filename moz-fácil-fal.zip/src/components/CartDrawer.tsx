import React, { useState } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  MapPin,
  Tag,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';
import { CartItem, api } from '../services/api.ts';
import { User, Order } from '../types/index.ts';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  user: User | null;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onOrderCreated: (order: Order) => void;
  onOpenAuth: () => void;
}

const PROVINCES_DELIVERY: Record<string, { label: string; fee: number }> = {
  'Maputo Cidade': { label: 'Maputo Cidade (Urbano)', fee: 200 },
  'Maputo Província': { label: 'Maputo Província (Matola / Boane)', fee: 250 },
  'Gaza': { label: 'Gaza (Xai-Xai, Chókwè)', fee: 450 },
  'Inhambane': { label: 'Inhambane (Maxixe, Vilankulo)', fee: 450 },
  'Sofala': { label: 'Sofala (Beira, Dondo)', fee: 600 },
  'Manica': { label: 'Manica (Chimoio)', fee: 600 },
  'Tete': { label: 'Tete (Cidade de Tete, Moatize)', fee: 650 },
  'Zambézia': { label: 'Zambézia (Quelimane, Mocuba)', fee: 700 },
  'Nampula': { label: 'Nampula (Nampula Cidade, Nacala)', fee: 750 },
  'Cabo Delgado': { label: 'Cabo Delgado (Pemba)', fee: 850 },
  'Niassa': { label: 'Niassa (Lichinga)', fee: 850 },
};

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  user,
  onUpdateQuantity,
  onRemoveItem,
  onOrderCreated,
  onOpenAuth,
}) => {
  const [step, setStep] = useState<'cart' | 'checkout'>('cart');
  const [province, setProvince] = useState(user?.province || 'Maputo Cidade');
  const [city, setCity] = useState(user?.city || 'Maputo');
  const [street, setStreet] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'mpesa' | 'emola'>('mpesa');

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number; desc: string } | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);

  const [loadingOrder, setLoadingOrder] = useState(false);
  const [orderError, setOrderError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Subtotal calculation
  const subtotal = cart.reduce((acc, item) => {
    let unitPrice = item.product.price;
    if (
      item.product.wholesalePrice &&
      item.product.wholesaleMinQty &&
      item.quantity >= item.product.wholesaleMinQty
    ) {
      unitPrice = item.product.wholesalePrice;
    }
    return acc + unitPrice * item.quantity;
  }, 0);

  const deliveryFee = PROVINCES_DELIVERY[province]?.fee || 250;
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  const total = Math.max(0, subtotal - discountAmount + (cart.length > 0 ? deliveryFee : 0));

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;
    setCouponLoading(true);
    setCouponError(null);
    try {
      const res = await api.validateCoupon(couponCode, subtotal);
      if (res.valid) {
        setAppliedCoupon({
          code: res.code,
          discount: res.discount,
          desc: res.description,
        });
      }
    } catch (err: any) {
      setCouponError(err.message || 'Cupom inválido.');
      setAppliedCoupon(null);
    } finally {
      setCouponLoading(false);
    }
  };

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }

    if (!street.trim()) {
      setOrderError('Por favor informe a morada exata para entrega.');
      return;
    }

    setLoadingOrder(true);
    setOrderError(null);

    try {
      const newOrder = await api.createOrder({
        items: cart.map((i) => ({ productId: i.product.id, quantity: i.quantity })),
        deliveryAddress: {
          province,
          city: city || province,
          street: street.trim(),
          notes: notes.trim(),
        },
        paymentMethod,
        couponCode: appliedCoupon?.code,
      });

      onOrderCreated(newOrder);
      onClose();
    } catch (err: any) {
      setOrderError(err.message || 'Erro ao criar pedido. Tente novamente.');
    } finally {
      setLoadingOrder(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl overflow-hidden border-l border-slate-200">
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-900 text-sm">
              {step === 'cart' ? 'Carrinho de Compras' : 'Finalizar Pedido'}
            </h3>
            <span className="text-xs text-slate-500">
              ({cart.reduce((sum, i) => sum + i.quantity, 0)} itens)
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <ShoppingBag className="w-16 h-16 text-slate-200 mb-3" />
            <h4 className="font-semibold text-slate-800 text-base mb-1">O seu carrinho está vazio</h4>
            <p className="text-xs text-slate-500 mb-6">
              Descubra os melhores produtos de agricultores, importadores e fornecedores de Moçambique.
            </p>
            <button
              onClick={onClose}
              className="py-2.5 px-5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Explorar Produtos
            </button>
          </div>
        ) : step === 'cart' ? (
          /* Step 1: Cart Items List */
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {cart.map(({ product, quantity }) => {
              const unitPrice =
                product.wholesalePrice &&
                product.wholesaleMinQty &&
                quantity >= product.wholesaleMinQty
                  ? product.wholesalePrice
                  : product.price;

              return (
                <div
                  key={product.id}
                  className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex gap-3 relative"
                >
                  <img
                    src={product.images[0] || ''}
                    alt={product.title}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-lg object-cover bg-white shrink-0 border border-slate-200"
                  />
                  <div className="flex-1 min-w-0 pr-6">
                    <h4 className="text-xs font-semibold text-slate-900 line-clamp-1">
                      {product.title}
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {product.sellerName} · {product.sellerCity}
                    </p>
                    <div className="flex items-baseline gap-1 mt-1 font-mono">
                      <span className="text-xs font-bold text-slate-900 tabular-nums">
                        {formatPrice(unitPrice * quantity)}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        ({formatPrice(unitPrice)}/{product.unitType})
                      </span>
                    </div>

                    {/* Stepper */}
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center border border-slate-300 rounded bg-white">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(product.id, quantity - 1)}
                          disabled={quantity <= product.moq}
                          className="p-1 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 text-xs font-bold font-mono">{quantity}</span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(product.id, quantity + 1)}
                          disabled={quantity >= product.stock}
                          className="p-1 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        Mínimo: {product.moq}
                      </span>
                    </div>
                  </div>

                  {/* Remove Item */}
                  <button
                    onClick={() => onRemoveItem(product.id)}
                    className="absolute top-3 right-3 text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                    title="Remover"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}

            {/* Delivery preview selector */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-500" />
                Destino de Entrega (Moçambique):
              </label>
              <select
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                className="w-full py-2 px-2.5 bg-white border border-slate-300 rounded-lg outline-none text-xs"
              >
                {Object.keys(PROVINCES_DELIVERY).map((prov) => (
                  <option key={prov} value={prov}>
                    {PROVINCES_DELIVERY[prov].label} — {PROVINCES_DELIVERY[prov].fee} MTn
                  </option>
                ))}
              </select>
            </div>

            {/* Coupon Code Box */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="Código de cupom (ex: BEMVINDO10)"
                    className="w-full py-2 pl-8 pr-2 bg-white border border-slate-300 rounded-lg outline-none uppercase font-mono text-xs"
                  />
                </div>
                <button
                  type="submit"
                  disabled={couponLoading}
                  className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold text-xs cursor-pointer"
                >
                  {couponLoading ? '...' : 'Aplicar'}
                </button>
              </form>
              {appliedCoupon && (
                <p className="text-[11px] text-emerald-700 font-medium mt-1.5 flex items-center gap-1">
                  <span>✓ {appliedCoupon.desc} (-{formatPrice(appliedCoupon.discount)})</span>
                </p>
              )}
              {couponError && (
                <p className="text-[11px] text-rose-600 mt-1.5">{couponError}</p>
              )}
            </div>
          </div>
        ) : (
          /* Step 2: Checkout Form */
          <form onSubmit={handleCheckoutSubmit} className="flex-1 overflow-y-auto p-4 space-y-4">
            {orderError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{orderError}</span>
              </div>
            )}

            {!user && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
                <p className="font-semibold mb-1">Inicie sessão para concluir a compra</p>
                <p className="text-amber-800 mb-2">
                  É necessário autenticar com o seu número de telefone de Moçambique.
                </p>
                <button
                  type="button"
                  onClick={onOpenAuth}
                  className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-lg text-xs cursor-pointer"
                >
                  Entrar ou Registar Agora
                </button>
              </div>
            )}

            {user && (
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                <span className="text-slate-500 block">Comprador:</span>
                <span className="font-semibold text-slate-900">{user.name} ({user.phone})</span>
              </div>
            )}

            {/* Address fields */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Morada de Entrega em Moçambique
              </h4>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Província</label>
                <select
                  value={province}
                  onChange={(e) => setProvince(e.target.value)}
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg text-xs bg-white outline-none"
                >
                  {Object.keys(PROVINCES_DELIVERY).map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Cidade / Bairro / Distrito
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Ex: Matola 700, Sommerschield, Munhava"
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg text-xs outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Rua, Número da Casa ou Ponto de Referência
                </label>
                <textarea
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  placeholder="Ex: Av. das FPLM nº 45, próximo à bomba Galp"
                  rows={2}
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg text-xs outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Instruções Adicionais (Opcional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Ligar antes de entregar"
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg text-xs outline-none"
                />
              </div>
            </div>

            {/* Payment Method Option */}
            <div className="pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Método de Pagamento Manual
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('mpesa')}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                    paymentMethod === 'mpesa'
                      ? 'border-emerald-500 bg-emerald-50/50 text-slate-900 shadow-xs'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="font-bold text-red-600">M-Pesa</div>
                  <div className="text-[11px] text-slate-500">Vodacom Moçambique</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('emola')}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                    paymentMethod === 'emola'
                      ? 'border-amber-500 bg-amber-50/50 text-slate-900 shadow-xs'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="font-bold text-amber-600">e-Mola</div>
                  <div className="text-[11px] text-slate-500">Movitel Moçambique</div>
                </button>
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                Após confirmar o pedido, receberá as instruções passo a passo para envio e confirmação do ID de transação.
              </p>
            </div>
          </form>
        )}

        {/* Drawer Footer Summary */}
        {cart.length > 0 && (
          <div className="p-4 border-t border-slate-200 bg-slate-50 space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal dos Produtos:</span>
                <span className="font-mono tabular-nums">{formatPrice(subtotal)}</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Desconto ({appliedCoupon.code}):</span>
                  <span className="font-mono tabular-nums">-{formatPrice(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Frete Estimado ({province}):</span>
                <span className="font-mono tabular-nums">{formatPrice(deliveryFee)}</span>
              </div>
              <div className="flex justify-between text-slate-900 font-extrabold text-sm pt-2 border-t border-slate-200">
                <span>Total a Pagar:</span>
                <span className="text-base font-mono tabular-nums text-slate-900">
                  {formatPrice(total)}
                </span>
              </div>
            </div>

            {step === 'cart' ? (
              <button
                type="button"
                onClick={() => {
                  if (!user) {
                    onOpenAuth();
                  } else {
                    setStep('checkout');
                  }
                }}
                className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
              >
                <span>Avançar para Entrega & Pagamento</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="py-3 px-4 border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer"
                >
                  Voltar
                </button>
                <button
                  type="button"
                  onClick={handleCheckoutSubmit}
                  disabled={loadingOrder || !user}
                  className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
                >
                  <ShieldCheck className="w-4 h-4" />
                  {loadingOrder ? 'A Criar Pedido...' : 'Confirmar Pedido & Pagar'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
