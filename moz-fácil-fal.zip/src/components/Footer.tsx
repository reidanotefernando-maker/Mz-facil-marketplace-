import React from 'react';
import { ShieldCheck, Phone, Mail, MapPin, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  onOpenRFQ: () => void;
  onOpenCategory: (cat: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenRFQ, onOpenCategory }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-16 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Trust & Guarantee Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pb-10 border-b border-slate-800 text-center sm:text-left">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white font-semibold text-sm">Proteção ao Comprador</h4>
              <p className="text-xs text-slate-400 mt-1">
                Pagamentos manuais verificados via M-Pesa e e-Mola. O valor é libertado ao vendedor com segurança.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white font-semibold text-sm">Fornecedores Verificados</h4>
              <p className="text-xs text-slate-400 mt-1">
                Produtores agrícolas, importadores e empresas industriais em Maputo, Beira, Nampula e Tete.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0 text-blue-400">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-white font-semibold text-sm">Cobertura Nacional</h4>
              <p className="text-xs text-slate-400 mt-1">
                Envios e logística estruturada para todas as 11 províncias de Moçambique.
              </p>
            </div>
          </div>
        </div>

        {/* 4-Column Footer Links */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 py-10 border-b border-slate-800 text-xs">
          {/* Col 1: Moz Fácil Fal */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-amber-500 flex items-center justify-center text-white font-bold text-sm">
                MF
              </div>
              <span className="text-white font-bold text-base font-display">Moz Fácil Fal</span>
            </div>
            <p className="text-slate-400 leading-relaxed mb-4">
              O maior portal de comércio, fornecedores grossistas e serviços locais de Moçambique. Conectamos empresas e cidadãos com transparência.
            </p>
            <div className="flex items-center gap-2 text-slate-400">
              <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
              <span>Av. 24 de Julho nº 1890, Maputo, Moçambique</span>
            </div>
          </div>

          {/* Col 2: Categorias */}
          <div>
            <h5 className="text-white font-semibold text-sm mb-3">Categorias Populares</h5>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => onOpenCategory('Agricultura & Alimentos')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Agricultura, Caju & Cereais
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenCategory('Construção & Ferragens')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Construção Civil & Cimento
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenCategory('Tecnologia & Eletrónica')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Energia Solar & Telemóveis
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenCategory('Serviços Técnicos & Reparação')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Reparações & Eletricistas
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenCategory('Transporte & Cargas')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Transporte de Cargas & Fretes
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Para Compradores e Vendedores */}
          <div>
            <h5 className="text-white font-semibold text-sm mb-3">Comércio em Moçambique</h5>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={onOpenRFQ}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Solicitar Cotação / RFQ
                </button>
              </li>
              <li>
                <span className="text-slate-400">Vender no Moz Fácil Fal (Comissão 5%)</span>
              </li>
              <li>
                <span className="text-slate-400">Regras de Moderação e Segurança</span>
              </li>
              <li>
                <span className="text-slate-400">Guia de Pagamentos M-Pesa & e-Mola</span>
              </li>
              <li>
                <span className="text-slate-400">Tabela de Fretes por Província</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Apoio ao Cliente */}
          <div>
            <h5 className="text-white font-semibold text-sm mb-3">Apoio ao Cliente & Contato</h5>
            <p className="text-slate-400 mb-3">
              Suporte telefónico de Segunda a Sábado, das 07h30 às 18h30.
            </p>
            <div className="space-y-2 text-slate-300">
              <a
                href="tel:+258847123456"
                className="flex items-center gap-2 hover:text-emerald-400 transition-colors"
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>+258 84 712 3456 (Vodacom)</span>
              </a>
              <a
                href="tel:+258869123456"
                className="flex items-center gap-2 hover:text-amber-400 transition-colors"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>+258 86 912 3456 (Movitel)</span>
              </a>
              <div className="flex items-center gap-2 text-slate-400">
                <Mail className="w-4 h-4 text-slate-500" />
                <span>contacto@mozfacilfal.co.mz</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Moz Fácil Fal Lda. Todos os direitos reservados. República de Moçambique.</p>
          <div className="flex items-center gap-4">
            <span>Privacidade</span>
            <span>·</span>
            <span>Termos de Uso</span>
            <span>·</span>
            <span>Avisos Legais</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
