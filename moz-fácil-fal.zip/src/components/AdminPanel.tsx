import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  CheckCircle,
  XCircle,
  DollarSign,
  Users,
  Package,
  Clock,
  Settings,
  History,
  AlertCircle,
  FileCheck,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { Order, Product, PlatformSettings, User } from '../types/index.ts';

interface AdminPanelProps {
  user: User;
  onRefreshData: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ user, onRefreshData }) => {
  const [stats, setStats] = useState<any>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'payments' | 'orders' | 'settings' | 'audit'>('payments');
  const [loading, setLoading] = useState(true);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // Settings editing state
  const [mpesaNumber, setMpesaNumber] = useState('');
  const [emolaNumber, setEmolaNumber] = useState('');
  const [commissionRate, setCommissionRate] = useState(5);
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const [s, ords, setts, logs] = await Promise.all([
        api.getAdminStats(),
        api.getOrders(),
        api.getAdminSettings(),
        api.request<any[]>('/api/admin/audit-logs'),
      ]);
      setStats(s);
      setOrders(ords);
      setSettings(setts);
      setAuditLogs(logs);

      if (setts) {
        setMpesaNumber(setts.mpesaNumber);
        setEmolaNumber(setts.emolaNumber);
        setCommissionRate(setts.commissionRatePercent);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyPayment = async (orderId: string, approved: boolean) => {
    try {
      const res = await api.verifyPayment(
        orderId,
        approved,
        approved ? undefined : 'Transação não localizada no extrato bancário/móvel'
      );
      if (res.success) {
        setActionFeedback(
          approved
            ? 'Pagamento verificado e confirmado com sucesso!'
            : 'Pagamento rejeitado e pedido revertido.'
        );
        loadAdminData();
        onRefreshData();
        setTimeout(() => setActionFeedback(null), 3000);
      }
    } catch (err: any) {
      alert(err.message || 'Erro ao processar verificação.');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await api.updateAdminSettings({
        mpesaNumber,
        emolaNumber,
        commissionRatePercent: Number(commissionRate),
      });
      setActionFeedback('Definições administrativas salvas!');
      setTimeout(() => setActionFeedback(null), 3000);
      loadAdminData();
    } catch (err: any) {
      alert(err.message || 'Erro ao salvar definições.');
    } finally {
      setSavingSettings(false);
    }
  };

  const formatPrice = (val: number) => {
    return (val || 0).toLocaleString('pt-MZ') + ' MTn';
  };

  const pendingPayments = orders.filter((o) => o.status === 'pagamento_sob_verificacao');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Admin Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 mb-8 border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center text-slate-900 font-bold">
              <ShieldCheck className="w-7 h-7 text-slate-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold font-display">
                  Painel de Administração Oficial
                </h1>
                <span className="text-[10px] font-bold uppercase bg-amber-500 text-slate-900 px-2 py-0.5 rounded">
                  Super Admin
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Gestão central de transações M-Pesa & e-Mola, moderação e comissões da plataforma
              </p>
            </div>
          </div>
        </div>

        {/* Admin KPI Ribbon */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800 text-xs">
            <div>
              <span className="text-slate-400 block">Volume Total (GMV)</span>
              <span className="text-lg font-bold font-mono text-white tabular-nums">
                {formatPrice(stats.totalGMV)}
              </span>
            </div>

            <div>
              <span className="text-slate-400 block">Receitas Comissões (5%)</span>
              <span className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
                {formatPrice(stats.totalCommission)}
              </span>
            </div>

            <div>
              <span className="text-slate-400 block">Pagamentos a Verificar</span>
              <span className="text-lg font-bold font-mono text-amber-400 tabular-nums">
                {stats.pendingPayments}
              </span>
            </div>

            <div>
              <span className="text-slate-400 block">Utilizadores Registados</span>
              <span className="text-lg font-bold font-mono text-white tabular-nums">
                {stats.totalUsers}
              </span>
            </div>
          </div>
        )}
      </div>

      {actionFeedback && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs mb-6 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionFeedback}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 mb-6 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('payments')}
          className={`py-2 px-4 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'payments'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Verificação de Pagamentos</span>
          {pendingPayments.length > 0 && (
            <span className="bg-amber-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
              {pendingPayments.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`py-2 px-4 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'orders'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Todos os Pedidos ({orders.length})
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`py-2 px-4 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'settings'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Settings className="w-4 h-4" />
          Definições & Contas M-Pesa/e-Mola
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`py-2 px-4 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'audit'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <History className="w-4 h-4" />
          Auditoria de Operações
        </button>
      </div>

      {/* Tab 1: Pending Payments Verification */}
      {activeTab === 'payments' && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-semibold">Instrução de Segurança Operacional:</strong>
              <span>
                Confronte o ID da transação informado pelo comprador com o extrato bancário ou SMS oficial recebido da Vodacom (M-Pesa) ou Movitel (e-Mola). Apenas confirme o pagamento após verificar a entrada efetiva do valor.
              </span>
            </div>
          </div>

          {pendingPayments.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8 text-xs text-slate-500">
              <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <p className="font-semibold text-slate-800 text-sm">Não há pagamentos pendentes de verificação</p>
              <p className="text-slate-400 mt-0.5">Todas as transações submetidas foram processadas.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingPayments.map((order) => (
                <div
                  key={order.id}
                  className="bg-white rounded-xl border border-amber-300 p-5 shadow-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                    <div>
                      <span className="font-bold text-slate-900 text-sm">
                        Pedido #{order.orderNumber}
                      </span>
                      <span className="text-xs text-slate-400 ml-2">
                        {new Date(order.createdAt).toLocaleString('pt-MZ')}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs uppercase font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                        {order.paymentMethod === 'mpesa' ? 'M-Pesa Vodacom' : 'e-Mola Movitel'}
                      </span>
                      <span className="font-extrabold font-mono text-base text-slate-900 tabular-nums">
                        {formatPrice(order.total)}
                      </span>
                    </div>
                  </div>

                  {/* Transaction Details Box */}
                  <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5">
                      <h4 className="font-bold text-slate-700">Comprovativo Submetido:</h4>
                      <p>
                        <span className="text-slate-500">Referência / ID Transação:</span>{' '}
                        <strong className="font-mono text-slate-900 text-sm px-1.5 py-0.5 bg-white border border-slate-300 rounded">
                          {order.paymentReference}
                        </strong>
                      </p>
                      {order.paymentNote && (
                        <p className="text-slate-600">
                          <span className="text-slate-500">Notas do Comprador:</span> {order.paymentNote}
                        </p>
                      )}
                      <p className="text-slate-500">
                        Comissão da plataforma (5%):{' '}
                        <strong className="text-emerald-700 font-mono">
                          {formatPrice(order.commissionAmount)}
                        </strong>
                      </p>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                      <h4 className="font-bold text-slate-700">Comprador:</h4>
                      <p className="font-semibold text-slate-900">{order.buyerName}</p>
                      <p className="text-slate-600">Telefone: {order.buyerPhone}</p>
                      <p className="text-slate-600">
                        Destino: {order.deliveryAddress.province}, {order.deliveryAddress.city}
                      </p>
                      <p className="text-slate-600">{order.deliveryAddress.street}</p>
                    </div>
                  </div>

                  {/* Admin Decision Actions */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3 text-xs">
                    <button
                      onClick={() => handleVerifyPayment(order.id, false)}
                      className="py-2 px-4 border border-rose-300 hover:bg-rose-50 text-rose-700 font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
                    >
                      <XCircle className="w-4 h-4" />
                      Rejeitar Pagamento
                    </button>
                    <button
                      onClick={() => handleVerifyPayment(order.id, true)}
                      className="py-2 px-5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Confirmar Pagamento & Libertar Pedido
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: All Orders */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs text-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Nº Pedido</th>
                  <th className="py-3 px-4">Comprador</th>
                  <th className="py-3 px-4">Total</th>
                  <th className="py-3 px-4">Comissão (5%)</th>
                  <th className="py-3 px-4">Método</th>
                  <th className="py-3 px-4">Estado</th>
                  <th className="py-3 px-4">Data</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {orders.map((o) => (
                  <tr key={o.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      #{o.orderNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">{o.buyerName}</div>
                      <div className="text-[11px] text-slate-400">{o.buyerPhone}</div>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                      {formatPrice(o.total)}
                    </td>
                    <td className="py-3 px-4 font-mono text-emerald-700 tabular-nums">
                      {formatPrice(o.commissionAmount)}
                    </td>
                    <td className="py-3 px-4 uppercase text-[11px] font-semibold text-slate-600">
                      {o.paymentMethod}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        o.status === 'pago'
                          ? 'bg-emerald-100 text-emerald-800'
                          : o.status === 'pagamento_sob_verificacao'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-800'
                      }`}>
                        {o.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {new Date(o.createdAt).toLocaleDateString('pt-MZ')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Settings */}
      {activeTab === 'settings' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 max-w-xl mx-auto shadow-xs text-xs">
          <h2 className="text-base font-bold text-slate-900 mb-1 font-display">
            Configuração de Pagamentos & Comissões
          </h2>
          <p className="text-slate-500 mb-6">
            Altere os números oficiais de M-Pesa e e-Mola apresentados aos compradores.
          </p>

          <form onSubmit={handleSaveSettings} className="space-y-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Número Vodacom M-Pesa Oficial
              </label>
              <input
                type="text"
                value={mpesaNumber}
                onChange={(e) => setMpesaNumber(e.target.value)}
                className="w-full py-2.5 px-3 border border-slate-300 rounded-lg outline-none font-mono font-semibold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Número Movitel e-Mola Oficial
              </label>
              <input
                type="text"
                value={emolaNumber}
                onChange={(e) => setEmolaNumber(e.target.value)}
                className="w-full py-2.5 px-3 border border-slate-300 rounded-lg outline-none font-mono font-semibold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Taxa de Comissão da Plataforma (%)
              </label>
              <input
                type="number"
                min="0"
                max="30"
                value={commissionRate}
                onChange={(e) => setCommissionRate(Number(e.target.value))}
                className="w-full py-2.5 px-3 border border-slate-300 rounded-lg outline-none font-mono font-semibold"
                required
              />
              <p className="text-[11px] text-slate-400 mt-1">
                A comissão padrão inicial é de 5% sobre o valor das mercadorias vendidas.
              </p>
            </div>

            <button
              type="submit"
              disabled={savingSettings}
              className="w-full py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer shadow-md"
            >
              {savingSettings ? 'A guardar...' : 'Salvar Alterações'}
            </button>
          </form>
        </div>
      )}

      {/* Tab 4: Audit Logs */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs text-xs">
          <div className="p-4 border-b border-slate-200 bg-slate-50 font-bold text-slate-700">
            Registo de Auditoria Operacional
          </div>
          <div className="divide-y divide-slate-100">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-3 hover:bg-slate-50 flex items-start justify-between gap-4">
                <div>
                  <span className="font-semibold text-slate-900 block">{log.action}</span>
                  <span className="text-slate-600">{log.details}</span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Operador / Telefone: {log.actorPhone}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 shrink-0">
                  {new Date(log.timestamp).toLocaleString('pt-MZ')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
