import React, { useState } from 'react';
import {
  Search,
  ShoppingCart,
  Heart,
  MessageSquare,
  User as UserIcon,
  ChevronDown,
  Building2,
  Sparkles,
  ShieldCheck,
  PhoneCall,
  LogOut,
  Package,
  Layers,
  Store,
} from 'lucide-react';
import { User } from '../types/index.ts';

interface HeaderProps {
  user: User | null;
  cartCount: number;
  favoritesCount: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  onOpenAuth: (initialTab?: 'login' | 'register') => void;
  onOpenCart: () => void;
  onOpenRFQ: () => void;
  onOpenMessages: () => void;
  onLogout: () => void;
  onAiSearch: () => void;
}

const CATEGORIES = [
  'Todas',
  'Agricultura & Alimentos',
  'Construção & Ferragens',
  'Tecnologia & Eletrónica',
  'Serviços Técnicos & Reparação',
  'Transporte & Cargas',
  'Moda, Tecidos & Capulanas',
  'Eletrodomésticos & Casa',
];

export const Header: React.FC<HeaderProps> = ({
  user,
  cartCount,
  favoritesCount,
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  onOpenAuth,
  onOpenCart,
  onOpenRFQ,
  onOpenMessages,
  onLogout,
  onAiSearch,
}) => {
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveTab('produtos');
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* 1. Top Utility Strip */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4 text-slate-300">
            <span className="flex items-center gap-1.5">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
              Moçambique · Maputo (GMT+2)
            </span>
            <span className="hidden sm:inline text-slate-600">|</span>
            <span className="hidden sm:inline">Moeda: Metical Moçambicano (MZN / MTn)</span>
            <span className="hidden md:inline text-slate-600">|</span>
            <span className="hidden md:flex items-center gap-1 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              Pagamentos Seguros com M-Pesa & e-Mola
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium">
            <button
              onClick={onOpenRFQ}
              className="text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
            >
              Pedir Cotação (RFQ)
            </button>
            <span className="text-slate-600">·</span>
            {user?.role === 'seller' ? (
              <button
                onClick={() => setActiveTab('vendedor')}
                className="text-white hover:underline cursor-pointer"
              >
                Painel do Vendedor
              </button>
            ) : (
              <button
                onClick={() => {
                  if (!user) onOpenAuth('register');
                  else setActiveTab('vendedor');
                }}
                className="text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                Como Vender no Moz Fácil Fal
              </button>
            )}
            <span className="text-slate-600">·</span>
            <a
              href="tel:+258847123456"
              className="flex items-center gap-1 text-slate-300 hover:text-white"
            >
              <PhoneCall className="w-3 h-3 text-emerald-400" />
              Apoio: +258 84 712 3456
            </a>
          </div>
        </div>
      </div>

      {/* 2. Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex items-center justify-between gap-4 lg:gap-8">
          {/* Brand Logo */}
          <button
            onClick={() => {
              setActiveTab('inicio');
              setSearchQuery('');
            }}
            className="flex items-center gap-2.5 shrink-0 text-left cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white font-extrabold text-xl shadow-xs group-hover:scale-105 transition-transform">
              MF
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-slate-900 font-display">
                  Moz Fácil Fal
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-sm bg-emerald-50 text-emerald-700 border border-emerald-200">
                  MZ
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                Marketplace & Fornecedores de Moçambique
              </p>
            </div>
          </button>

          {/* Alibaba-style Multi-tier Search Bar */}
          <div className="flex-1 max-w-2xl hidden md:block">
            <form onSubmit={handleSearchSubmit} className="flex items-center">
              <div className="flex items-center w-full border-2 border-amber-500 rounded-lg overflow-hidden bg-white focus-within:ring-2 focus-within:ring-amber-400">
                {/* Category selector */}
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-slate-50 text-slate-700 text-xs font-medium py-2.5 px-3 border-r border-slate-200 outline-none cursor-pointer hover:bg-slate-100"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>

                {/* Input */}
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Pesquise por caju, milho, cimento, smartphones, gerador solar, fretes..."
                  className="w-full py-2.5 px-3 text-sm text-slate-900 placeholder-slate-400 outline-none"
                />

                {/* AI Search Assistant Trigger */}
                <button
                  type="button"
                  onClick={onAiSearch}
                  title="Pesquisa inteligente com IA"
                  className="px-2.5 py-2 text-amber-600 hover:text-amber-700 bg-amber-50 hover:bg-amber-100 transition-colors flex items-center gap-1 text-xs font-medium cursor-pointer shrink-0"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span className="hidden xl:inline">IA</span>
                </button>

                {/* Search Button */}
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-600 text-white font-medium px-5 py-2.5 transition-colors flex items-center gap-1.5 text-sm cursor-pointer shrink-0"
                >
                  <Search className="w-4 h-4" />
                  <span className="font-semibold">Buscar</span>
                </button>
              </div>
            </form>
          </div>

          {/* Right Action Icons & Meu Moz Fácil Fal Account */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* RFQ CTA Button */}
            <button
              onClick={onOpenRFQ}
              className="hidden lg:flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold py-2 px-3.5 rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <Building2 className="w-3.5 h-3.5 text-amber-400" />
              Solicitar Orçamento
            </button>

            {/* Messages */}
            <button
              onClick={onOpenMessages}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative cursor-pointer"
              title="Mensagens e Negociações"
            >
              <MessageSquare className="w-5 h-5" />
            </button>

            {/* Favorites */}
            <button
              onClick={() => setActiveTab('favoritos')}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative cursor-pointer"
              title="Meus Favoritos"
            >
              <Heart className="w-5 h-5" />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Cart */}
            <button
              onClick={onOpenCart}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative cursor-pointer flex items-center gap-1"
              title="Carrinho de Compras"
            >
              <ShoppingCart className="w-5 h-5 text-amber-600" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Account Menu (Meu Moz Fácil Fal) */}
            <div className="relative">
              <button
                onClick={() => setAccountMenuOpen(!accountMenuOpen)}
                className="flex items-center gap-1.5 p-1.5 sm:px-3 sm:py-1.5 rounded-lg border border-slate-200 hover:border-slate-300 bg-white text-slate-700 hover:bg-slate-50 text-xs font-medium transition-colors cursor-pointer"
              >
                <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                  <UserIcon className="w-3.5 h-3.5" />
                </div>
                <div className="text-left hidden sm:block">
                  <span className="block text-[10px] text-slate-400 leading-tight">
                    {user ? 'Olá,' : 'Bem-vindo'}
                  </span>
                  <span className="block font-semibold text-slate-900 leading-tight truncate max-w-[100px]">
                    {user ? user.name.split(' ')[0] : 'Meu Moz'}
                  </span>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {/* Dropdown Menu */}
              {accountMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-sm"
                  onMouseLeave={() => setAccountMenuOpen(false)}
                >
                  <div className="px-4 py-3 border-b border-slate-100">
                    {user ? (
                      <div>
                        <p className="font-semibold text-slate-900">{user.name}</p>
                        <p className="text-xs text-slate-500">{user.phone}</p>
                        <span className="inline-block mt-1 text-[10px] font-semibold uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded-sm">
                          {user.role === 'admin'
                            ? 'Administrador'
                            : user.role === 'seller'
                            ? 'Vendedor Verificado'
                            : 'Comprador'}
                        </span>
                      </div>
                    ) : (
                      <div>
                        <p className="font-semibold text-slate-900">Meu Moz Fácil Fal</p>
                        <p className="text-xs text-slate-500 mb-2">Acesse para gerir pedidos e mensagens</p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              setAccountMenuOpen(false);
                              onOpenAuth('login');
                            }}
                            className="flex-1 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold py-1.5 rounded-md text-center cursor-pointer"
                          >
                            Entrar
                          </button>
                          <button
                            onClick={() => {
                              setAccountMenuOpen(false);
                              onOpenAuth('register');
                            }}
                            className="flex-1 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold py-1.5 rounded-md text-center cursor-pointer"
                          >
                            Registar
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        setAccountMenuOpen(false);
                        setActiveTab('pedidos');
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center gap-2.5 text-slate-700 cursor-pointer"
                    >
                      <Package className="w-4 h-4 text-slate-400" />
                      Gerir Pedidos & Compras
                    </button>
                    <button
                      onClick={() => {
                        setAccountMenuOpen(false);
                        onOpenMessages();
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center gap-2.5 text-slate-700 cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4 text-slate-400" />
                      Mensagens e Negociações
                    </button>
                    <button
                      onClick={() => {
                        setAccountMenuOpen(false);
                        setActiveTab('favoritos');
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center gap-2.5 text-slate-700 cursor-pointer"
                    >
                      <Heart className="w-4 h-4 text-slate-400" />
                      Meus Favoritos
                    </button>
                    <button
                      onClick={() => {
                        setAccountMenuOpen(false);
                        setActiveTab('vendedor');
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center gap-2.5 text-slate-700 cursor-pointer"
                    >
                      <Store className="w-4 h-4 text-slate-400" />
                      {user?.role === 'seller' ? 'Área do Vendedor' : 'Vender no Moz Fácil Fal'}
                    </button>

                    {user?.role === 'admin' && (
                      <button
                        onClick={() => {
                          setAccountMenuOpen(false);
                          setActiveTab('admin');
                        }}
                        className="w-full text-left px-4 py-2 bg-amber-50 hover:bg-amber-100 flex items-center gap-2.5 text-amber-900 font-semibold cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4 text-amber-600" />
                        Painel Administrativo
                      </button>
                    )}
                  </div>

                  {user && (
                    <div className="border-t border-slate-100 pt-1">
                      <button
                        onClick={() => {
                          setAccountMenuOpen(false);
                          onLogout();
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-rose-50 text-rose-600 flex items-center gap-2.5 text-xs font-semibold cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" />
                        Terminar Sessão
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Search input */}
        <div className="mt-3 block md:hidden">
          <form onSubmit={handleSearchSubmit} className="flex items-center">
            <div className="flex items-center w-full border border-amber-500 rounded-lg overflow-hidden bg-white">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Pesquise produtos, serviços ou fornecedores..."
                className="w-full py-2 px-3 text-xs text-slate-900 outline-none"
              />
              <button
                type="submit"
                className="bg-amber-500 text-white p-2 text-xs font-medium cursor-pointer"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* 3. Category & Navigation Ribbon */}
      <div className="bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto py-2 text-xs font-medium no-scrollbar">
            <button
              onClick={() => {
                setActiveTab('inicio');
                setSelectedCategory('Todas');
              }}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'inicio'
                  ? 'bg-amber-500 text-white font-semibold'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Início
            </button>
            <button
              onClick={() => setActiveTab('produtos')}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'produtos'
                  ? 'bg-amber-500 text-white font-semibold'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Catálogo de Produtos
            </button>
            <button
              onClick={() => setActiveTab('servicos')}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'servicos'
                  ? 'bg-amber-500 text-white font-semibold'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Serviços & Profissionais
            </button>
            <button
              onClick={() => setActiveTab('fornecedores')}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'fornecedores'
                  ? 'bg-amber-500 text-white font-semibold'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Fornecedores & Fabricantes
            </button>
            <button
              onClick={() => setActiveTab('rfqs')}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'rfqs'
                  ? 'bg-amber-500 text-white font-semibold'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Cotações Abertas (RFQ)
            </button>
            <button
              onClick={() => setActiveTab('vendedores-locais')}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'vendedores-locais'
                  ? 'bg-amber-500 text-white font-semibold'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Vendedores por Província
            </button>
            <button
              onClick={() => setActiveTab('pedidos')}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'pedidos'
                  ? 'bg-amber-500 text-white font-semibold'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Meus Pedidos
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
