import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  CheckCircle,
  Copy,
  Clock,
  AlertCircle,
  HelpCircle,
  FileCheck,
} from 'lucide-react';
import { Order } from '../types/index.ts';
import { api } from '../services/api.ts';

interface OrderPaymentModalProps {
  order: Order | null;
  onClose: () => void;
  onPaymentSubmitted: (updatedOrder: Order) => void;
}

export const OrderPaymentModal: React.FC<OrderPaymentModalProps> = ({
  order,
  onClose,
  onPaymentSubmitted,
}) => {
  if (!order) return null;

  const [paymentReference, setPaymentReference] = useState(order.paymentReference || '');
  const [paymentNote, setPaymentNote] = useState(order.paymentNote || '');
  const [copied, setCopied] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  const isMpesa = order.paymentMethod === 'mpesa';
  const targetNumber = isMpesa ? '847123456' : '869123456';
  const targetFormatted = isMpesa ? '84 712 3456' : '86 912 3456';
  const targetName = isMpesa ? 'Moz Fácil Fal Lda - M-Pesa Negócios' : 'Moz Fácil Fal Lda - e-Mola Comercial';

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentReference.trim()) {
      setError('Por favor insira o ID ou Referência da mensagem de confirmação do M-Pesa ou e-Mola.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const updated = await api.submitPaymentProof(order.id, paymentReference, paymentNote);
      setSuccess(true);
      onPaymentSubmitted(updated);
    } catch (err: any) {
      setError(err.message || 'Erro ao enviar comprovativo.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200 my-auto">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
              isMpesa ? 'bg-red-600 text-white' : 'bg-amber-500 text-slate-900'
            }`}>
              {isMpesa ? 'MP' : 'eM'}
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base font-display">
                Pagamento do Pedido #{order.orderNumber}
              </h3>
              <p className="text-xs text-slate-400">
                Moçambique · Instruções {isMpesa ? 'M-Pesa (Vodacom)' : 'e-Mola (Movitel)'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* Order Summary box */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 block">Total a transferir:</span>
              <span className="text-2xl font-extrabold text-slate-900 font-mono tracking-tight tabular-nums">
                {formatPrice(order.total)}
              </span>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-500 block">Estado atual:</span>
              <span className={`inline-block text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                order.status === 'pago'
                  ? 'bg-emerald-100 text-emerald-800'
                  : order.status === 'pagamento_sob_verificacao'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-slate-200 text-slate-800'
              }`}>
                {order.status === 'pago'
                  ? 'Pago & Confirmado'
                  : order.status === 'pagamento_sob_verificacao'
                  ? 'Sob Verificação'
                  : 'Aguardando Pagamento'}
              </span>
            </div>
          </div>

          {/* Instructions Step-by-Step */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Passo a Passo para Pagamento Manual
            </h4>

            <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2 text-xs text-slate-700">
              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                  1
                </span>
                <p>
                  No seu telemóvel, marque o código USSD:{' '}
                  <strong className="font-mono">{isMpesa ? '*150#' : '*898#'}</strong>.
                </p>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                  2
                </span>
                <p>
                  Escolha <strong>Transferir Dinheiro</strong> ou Pagamento de Serviços.
                </p>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                  3
                </span>
                <div className="flex-1">
                  <p>
                    Transfira para o número oficial da plataforma:{' '}
                    <strong className="font-mono text-slate-900">{targetFormatted}</strong> ({targetName}).
                  </p>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(targetNumber, 'número')}
                    className="mt-1 text-[11px] text-amber-600 hover:text-amber-700 flex items-center gap-1 font-semibold cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    {copied === 'número' ? 'Copiado!' : 'Copiar Número'}
                  </button>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                  4
                </span>
                <p>
                  Insira o valor exato:{' '}
                  <strong className="font-mono text-slate-900">{formatPrice(order.total)}</strong>.
                </p>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                  5
                </span>
                <p>
                  Confirme com o seu PIN pessoal e guarde o SMS com o <strong>ID da Transação</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Form to submit transaction reference */}
          {order.status === 'pago' ? (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600 shrink-0" />
              <div>
                <p className="font-bold">Pagamento Verificado com Sucesso!</p>
                <p className="text-emerald-800 mt-0.5">
                  A encomenda está confirmada e o vendedor já foi notificado para preparar o envio.
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmitProof} className="space-y-3 pt-2 border-t border-slate-200">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-amber-600" />
                Informar ID / Referência da Transação
              </h4>

              {error && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    Referência guardada com sucesso! O estado do seu pedido foi atualizado para "Sob Verificação".
                  </span>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  ID da Transação {isMpesa ? 'M-Pesa' : 'e-Mola'}
                </label>
                <input
                  type="text"
                  value={paymentReference}
                  onChange={(e) => setPaymentReference(e.target.value)}
                  placeholder="Ex: CI9892KJ402 ou MP260901..."
                  className="w-full text-xs font-mono font-bold uppercase py-2.5 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500 bg-white"
                  required
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  Encontra este código no SMS recebido da Vodacom ou Movitel.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Notas ou Número do Remetente (Opcional)
                </label>
                <input
                  type="text"
                  value={paymentNote}
                  onChange={(e) => setPaymentNote(e.target.value)}
                  placeholder="Ex: Transferido pelo número 84 999 8888 às 15:30"
                  className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500 bg-white"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
              >
                <Clock className="w-4 h-4" />
                {submitting ? 'A enviar...' : 'Submeter Comprovativo para Verificação'}
              </button>

              <p className="text-[11px] text-slate-400 text-center leading-tight">
                A nossa equipa administrativa valida as transações no extrato oficial do M-Pesa/e-Mola antes de libertar a mercadoria.
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
