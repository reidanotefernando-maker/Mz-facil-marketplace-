import React, { useState } from 'react';
import { X, Phone, Lock, User as UserIcon, Building2, AlertCircle, CheckCircle } from 'lucide-react';
import { api } from '../services/api.ts';
import { User } from '../types/index.ts';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
  initialTab?: 'login' | 'register';
}

const PROVINCES = [
  'Maputo Cidade',
  'Maputo Província',
  'Gaza',
  'Inhambane',
  'Sofala',
  'Manica',
  'Tete',
  'Zambézia',
  'Nampula',
  'Cabo Delgado',
  'Niassa',
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialTab = 'login',
}) => {
  const [tab, setTab] = useState<'login' | 'register'>(initialTab);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');
  const [businessName, setBusinessName] = useState('');
  const [province, setProvince] = useState('Maputo Cidade');
  const [city, setCity] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!phone) {
      setError('Por favor insira o número de telefone.');
      return;
    }

    if (!password) {
      setError('Por favor insira a palavra-passe.');
      return;
    }

    if (tab === 'register') {
      if (!name) {
        setError('Por favor insira o seu nome completo ou nome comercial.');
        return;
      }
      if (password !== confirmPassword) {
        setError('As palavras-passe não coincidem.');
        return;
      }
      if (password.length < 6) {
        setError('A palavra-passe deve ter pelo menos 6 caracteres.');
        return;
      }
      if (!acceptTerms) {
        setError('Deve aceitar os Termos de Uso e a Política de Privacidade de Moçambique.');
        return;
      }
    }

    setLoading(true);
    try {
      if (tab === 'login') {
        const res = await api.login(phone, password);
        onSuccess(res.user);
        onClose();
      } else {
        const res = await api.register({
          name,
          phone,
          password,
          role,
          businessName: role === 'seller' ? businessName : undefined,
          province,
          city: city || province,
        });
        onSuccess(res.user);
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao autenticar. Verifique os seus dados.');
    } finally {
      setLoading(false);
    }
  };

  // Quick Demo Account filler for easy evaluation
  const handleQuickDemo = (demoType: 'admin' | 'seller' | 'buyer') => {
    setTab('login');
    setError(null);
    if (demoType === 'admin') {
      setPhone('840000000');
      setPassword('admin123');
    } else if (demoType === 'seller') {
      setPhone('841234567');
      setPassword('vendedor123');
    } else {
      setPhone('823456789');
      setPassword('cliente123');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center font-bold text-white text-sm">
              MF
            </div>
            <div>
              <h3 className="font-bold text-base font-display">Acesso ao Moz Fácil Fal</h3>
              <p className="text-xs text-slate-400">Autenticação com número de Moçambique</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-100 border-b border-slate-200 text-xs font-semibold">
          <button
            onClick={() => {
              setTab('login');
              setError(null);
            }}
            className={`py-2 text-center rounded-lg transition-colors cursor-pointer ${
              tab === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Entrar com Telefone
          </button>
          <button
            onClick={() => {
              setTab('register');
              setError(null);
            }}
            className={`py-2 text-center rounded-lg transition-colors cursor-pointer ${
              tab === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Criar Nova Conta
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {tab === 'register' && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Nome Completo ou Nome Comercial
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: João Machel ou Agro-Comércio Lda"
                    className="w-full text-xs py-2.5 pl-9 pr-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Tipo de Conta
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setRole('buyer')}
                    className={`py-2 px-3 rounded-lg border text-center transition-colors cursor-pointer ${
                      role === 'buyer'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900 font-semibold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Comprador
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('seller')}
                    className={`py-2 px-3 rounded-lg border text-center transition-colors cursor-pointer ${
                      role === 'seller'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900 font-semibold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Vendedor / Empresa
                  </button>
                </div>
              </div>

              {role === 'seller' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Nome da Empresa / Atividade Comercial
                  </label>
                  <div className="relative">
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      placeholder="Ex: Distribuidora Central de Maputo"
                      className="w-full text-xs py-2.5 pl-9 pr-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Província
                  </label>
                  <select
                    value={province}
                    onChange={(e) => setProvince(e.target.value)}
                    className="w-full text-xs py-2.5 px-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500 bg-white"
                  >
                    {PROVINCES.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Cidade / Distrito
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Ex: Matola, Beira"
                    className="w-full text-xs py-2.5 px-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Número de Telefone (Moçambique)
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="84 123 4567 ou +258 84..."
                className="w-full text-xs py-2.5 pl-9 pr-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500 font-mono"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              Aceita Vodacom (84/85), Movitel (86/87) ou Tmcel (82/83)
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Palavra-passe
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mínimo 6 caracteres"
                className="w-full text-xs py-2.5 pl-9 pr-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500"
                required
              />
            </div>
          </div>

          {tab === 'register' && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Confirmar Palavra-passe
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repita a palavra-passe"
                    className="w-full text-xs py-2.5 pl-9 pr-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500"
                    required
                  />
                </div>
              </div>

              <div className="flex items-start gap-2 pt-1">
                <input
                  type="checkbox"
                  id="terms"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300 text-amber-500 focus:ring-amber-400"
                />
                <label htmlFor="terms" className="text-[11px] text-slate-600 leading-tight">
                  Concordo com os Termos de Utilização do Moz Fácil Fal e com o tratamento de dados segundo a legislação de Moçambique.
                </label>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold py-2.5 rounded-lg text-xs transition-colors cursor-pointer shadow-xs"
          >
            {loading
              ? 'A processar...'
              : tab === 'login'
              ? 'Entrar no Moz Fácil Fal'
              : 'Criar Minha Conta'}
          </button>

          {/* Demo account quick login box */}
          <div className="pt-3 border-t border-slate-100">
            <p className="text-[11px] font-semibold text-slate-500 mb-2 text-center">
              Acesso Rápido para Demonstração:
            </p>
            <div className="grid grid-cols-3 gap-1.5 text-[10px]">
              <button
                type="button"
                onClick={() => handleQuickDemo('buyer')}
                className="py-1 px-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-center transition-colors cursor-pointer"
              >
                Comprador
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('seller')}
                className="py-1 px-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-center transition-colors cursor-pointer"
              >
                Vendedor Agro
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('admin')}
                className="py-1 px-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 font-semibold rounded text-center transition-colors cursor-pointer"
              >
                Administrador
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
