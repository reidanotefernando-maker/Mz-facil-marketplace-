import React from 'react';
import { MapPin, ArrowRight, Store, ShieldCheck } from 'lucide-react';

interface ProvincesDirectoryProps {
  onSelectProvince: (prov: string) => void;
}

const PROVINCES_DATA = [
  {
    name: 'Maputo Cidade',
    capital: 'Maputo',
    desc: 'Maior polo comercial, portuário e financeiro de Moçambique. Importadores, tecnologia e bens de consumo.',
    hubs: ['Porto de Maputo', 'Av. 24 de Julho', 'Polana Caniço'],
    badge: 'Polo Comercial Sul',
  },
  {
    name: 'Maputo Província',
    capital: 'Matola',
    desc: 'Zona industrial de excelência, metalurgia, montagem automóvel, cimentos e materiais de construção.',
    hubs: ['Zona Industrial da Matola', 'Boane', 'Marracuene'],
    badge: 'Indústria & Fábricas',
  },
  {
    name: 'Sofala',
    capital: 'Beira',
    desc: 'Porto da Beira, corredor de transporte para o centro de Moçambique, Zimbabué e Zâmbia. Ferragens e cimento.',
    hubs: ['Porto da Beira', 'Munhava', 'Dondo'],
    badge: 'Corredor Central',
  },
  {
    name: 'Nampula',
    capital: 'Nampula',
    desc: 'Capital do norte moçambicano, polo de comercialização de castanha de caju, gergelim e cereais para exportação.',
    hubs: ['Corredor de Nacala', 'Mercado Central', 'Angoche'],
    badge: 'Celeiro Agrícola & Caju',
  },
  {
    name: 'Tete',
    capital: 'Cidade de Tete',
    desc: 'Mineração de carvão, barragem de Cahora Bassa, pecuária e comércio transfronteiriço com Malawi.',
    hubs: ['Moatize', 'Rio Zambeze', 'Songo'],
    badge: 'Energia & Recursos',
  },
  {
    name: 'Zambézia',
    capital: 'Quelimane',
    desc: 'Produção de copra, arroz nacional, chá e transporte fluvial. Comércio grossista tradicional.',
    hubs: ['Quelimane', 'Mocuba', 'Gurúè'],
    badge: 'Agricultura & Tradição',
  },
  {
    name: 'Manica',
    capital: 'Chimoio',
    desc: 'Agricultura comercial intensiva, frutas tropicais, hortícolas e madeira de primeira qualidade.',
    hubs: ['Chimoio', 'Manica', 'Gondola'],
    badge: 'Hortifrutícola',
  },
  {
    name: 'Gaza',
    capital: 'Xai-Xai',
    desc: 'Vale do Limpopo, maior produtor de arroz e tomate de Moçambique, praias e turismo costeiro.',
    hubs: ['Regadio do Chókwè', 'Xai-Xai', 'Bilene'],
    badge: 'Regadio & Arroz',
  },
  {
    name: 'Inhambane',
    capital: 'Maxixe / Inhambane',
    desc: 'Pesca, coco, castanha, turismo de classe mundial e comércio marítimo.',
    hubs: ['Maxixe', 'Vilankulo', 'Tofo'],
    badge: 'Pesca & Coco',
  },
  {
    name: 'Cabo Delgado',
    capital: 'Pemba',
    desc: 'Gás natural liquefeito (GNL), mármores de Montepuez, rubis e corredor de Pemba.',
    hubs: ['Baía de Pemba', 'Montepuez', 'Palma'],
    badge: 'Gás & Gemas',
  },
  {
    name: 'Niassa',
    capital: 'Lichinga',
    desc: 'Planalto fresco, silvicultura, pinhais, feijão manteiga e batata de alta cota.',
    hubs: ['Lichinga', 'Cuamba', 'Lago Niassa'],
    badge: 'Silvicultura & Madeira',
  },
];

export const ProvincesDirectory: React.FC<ProvincesDirectoryProps> = ({ onSelectProvince }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <span className="text-xs uppercase font-bold tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
          Geografia Comercial
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-2">
          Vendedores & Fornecedores por Província
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
          Encontre produtores locais, distribuidores autorizados e serviços especializados na sua região de Moçambique.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {PROVINCES_DATA.map((prov) => (
          <div
            key={prov.name}
            onClick={() => onSelectProvince(prov.name)}
            className="bg-white rounded-xl border border-slate-200 p-5 hover:border-amber-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-slate-100 text-slate-700 rounded">
                  {prov.badge}
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-500" />
                  {prov.capital}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-base group-hover:text-amber-600 transition-colors">
                {prov.name}
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed mt-2 mb-4">
                {prov.desc}
              </p>

              {/* Hubs tags */}
              <div className="flex flex-wrap gap-1.5 text-[10px] text-slate-500">
                {prov.hubs.map((hub) => (
                  <span key={hub} className="px-2 py-0.5 bg-slate-50 border border-slate-100 rounded">
                    {hub}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-amber-600 group-hover:text-amber-700">
              <span>Ver Vendedores & Produtos</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
