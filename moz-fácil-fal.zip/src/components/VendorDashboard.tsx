import React, { useState, useEffect } from 'react';
import {
  Package,
  PlusCircle,
  TrendingUp,
  DollarSign,
  Clock,
  CheckCircle,
  Truck,
  Trash2,
  Edit3,
  Store,
  ShieldCheck,
  Building2,
  AlertCircle,
} from 'lucide-react';
import { Product, ServiceItem, Order, User } from '../types/index.ts';
import { api } from '../services/api.ts';

interface VendorDashboardProps {
  user: User;
  onRefreshData: () => void;
  onOpenNewService: () => void;
}

const CATEGORIES = [
  'Agricultura & Alimentos',
  'Construção & Ferragens',
  'Tecnologia & Eletrónica',
  'Serviços Técnicos & Reparação',
  'Transporte & Cargas',
  'Moda, Tecidos & Capulanas',
  'Eletrodomésticos & Casa',
];

const UNIT_TYPES = ['unidade', 'conjunto', 'kg', 'saco', 'tonelada', 'metro', 'lote'];

export const VendorDashboard: React.FC<VendorDashboardProps> = ({
  user,
  onRefreshData,
  onOpenNewService,
}) => {
  const [activeTab, setActiveTab] = useState<'listings' | 'new_product' | 'orders'>('listings');
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  // New product form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [wholesalePrice, setWholesalePrice] = useState('');
  const [wholesaleMinQty, setWholesaleMinQty] = useState('');
  const [unitType, setUnitType] = useState('unidade');
  const [moq, setMoq] = useState(1);
  const [stock, setStock] = useState(10);
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [subcategory, setSubcategory] = useState('');
  const [imageUrl, setImageUrl] = useState('/src/assets/images/product_construction_hardware_1792475629674.jpg');
  const [deliveryInfo, setDeliveryInfo] = useState('');

  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    loadVendorData();
  }, [user]);

  const loadVendorData = async () => {
    setLoading(true);
    try {
      const [prods, ords] = await Promise.all([
        api.getProducts({ sellerId: user.id }),
        api.getOrders(),
      ]);
      setProducts(prods);
      setOrders(ords.filter((o) => o.items.some((i) => i.sellerId === user.id)));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim() || !price) {
      setMessage({ type: 'error', text: 'Preencha título, descrição e preço.' });
      return;
    }

    setSaving(true);
    setMessage(null);

    try {
      await api.createProduct({
        title: title.trim(),
        description: description.trim(),
        price: Number(price),
        wholesalePrice: wholesalePrice ? Number(wholesalePrice) : undefined,
        wholesaleMinQty: wholesaleMinQty ? Number(wholesaleMinQty) : undefined,
        unitType: unitType as any,
        moq: Number(moq),
        stock: Number(stock),
        category,
        subcategory,
        images: [imageUrl],
        deliveryInfo,
      });

      setMessage({ type: 'success', text: 'Produto anunciado com sucesso no Moz Fácil Fal!' });
      setTitle('');
      setDescription('');
      setPrice('');
      setWholesalePrice('');
      setWholesaleMinQty('');
      setActiveTab('listings');
      loadVendorData();
      onRefreshData();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Erro ao publicar produto.' });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Tem a certeza que deseja eliminar este anúncio?')) return;
    try {
      await api.deleteProduct(id);
      loadVendorData();
      onRefreshData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      await api.updateOrderStatus(orderId, newStatus);
      loadVendorData();
    } catch (e) {
      console.error(e);
    }
  };

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  // Vendor financial metrics
  const totalEarned = orders
    .filter((o) => o.status === 'pago' || o.status === 'concluido')
    .reduce((sum, o) => sum + o.sellerPayout, 0);

  const pendingShipment = orders.filter((o) => o.status === 'pago' || o.status === 'em_preparacao').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Vendor Profile Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 mb-8 border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 flex items-center justify-center text-white text-2xl font-bold font-display shadow-lg">
              <Store className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold font-display">
                  {user.businessName || user.name}
                </h1>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded">
                  Vendedor Autorizado
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {user.city || user.province} · {user.phone} · Comissão de plataforma: 5%
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('new_product')}
              className="py-2.5 px-4 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-md"
            >
              <PlusCircle className="w-4 h-4" />
              Publicar Novo Produto
            </button>
            <button
              onClick={onOpenNewService}
              className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Building2 className="w-4 h-4" />
              Publicar Serviço
            </button>
          </div>
        </div>

        {/* Vendor Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 pt-6 border-t border-slate-800">
          <div>
            <span className="text-slate-400 text-xs block">Vendas Líquidas Recebidas</span>
            <span className="text-lg sm:text-xl font-bold font-mono text-emerald-400 tabular-nums">
              {formatPrice(totalEarned)}
            </span>
          </div>

          <div>
            <span className="text-slate-400 text-xs block">Pedidos a Despachar</span>
            <span className="text-lg sm:text-xl font-bold font-mono text-amber-400 tabular-nums">
              {pendingShipment}
            </span>
          </div>

          <div>
            <span className="text-slate-400 text-xs block">Anúncios no Catálogo</span>
            <span className="text-lg sm:text-xl font-bold font-mono text-white tabular-nums">
              {products.length}
            </span>
          </div>

          <div>
            <span className="text-slate-400 text-xs block">Total de Pedidos</span>
            <span className="text-lg sm:text-xl font-bold font-mono text-white tabular-nums">
              {orders.length}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 mb-6 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('listings')}
          className={`py-2 px-4 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'listings'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Meus Anúncios ({products.length})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`py-2 px-4 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'orders'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Pedidos de Clientes ({orders.length})
        </button>
        <button
          onClick={() => setActiveTab('new_product')}
          className={`py-2 px-4 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'new_product'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          + Publicar Anúncio
        </button>
      </div>

      {/* Tab 1: Listings */}
      {activeTab === 'listings' && (
        <div className="space-y-4">
          {products.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8">
              <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-semibold text-slate-800 text-base">Ainda não tem produtos publicados</h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Comece a vender para milhares de compradores em Moçambique.
              </p>
              <button
                onClick={() => setActiveTab('new_product')}
                className="py-2 px-4 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-lg cursor-pointer"
              >
                Publicar Primeiro Produto
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Produto</th>
                      <th className="py-3 px-4">Preço Unitário</th>
                      <th className="py-3 px-4">Atacado</th>
                      <th className="py-3 px-4">Mínimo (MOQ)</th>
                      <th className="py-3 px-4">Stock</th>
                      <th className="py-3 px-4">Estado</th>
                      <th className="py-3 px-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 flex items-center gap-3">
                          <img
                            src={p.images[0] || ''}
                            alt=""
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 rounded object-cover bg-slate-100 border border-slate-200 shrink-0"
                          />
                          <div className="min-w-0">
                            <span className="font-semibold text-slate-900 block truncate max-w-xs">
                              {p.title}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              {p.category}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                          {formatPrice(p.price)}/{p.unitType}
                        </td>
                        <td className="py-3 px-4 text-emerald-700 font-mono tabular-nums">
                          {p.wholesalePrice ? `${formatPrice(p.wholesalePrice)} (≥${p.wholesaleMinQty})` : '—'}
                        </td>
                        <td className="py-3 px-4">
                          {p.moq} {p.unitType}(s)
                        </td>
                        <td className="py-3 px-4 font-mono">{p.stock}</td>
                        <td className="py-3 px-4">
                          <span className="inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                            {p.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Eliminar anúncio"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Orders Received */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {orders.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8">
              <Truck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-semibold text-slate-800 text-base">Sem pedidos recebidos</h3>
              <p className="text-xs text-slate-500 mt-1">
                Quando os compradores confirmarem encomendas dos seus artigos, aparecerão aqui.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((o) => (
                <div key={o.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
                    <div>
                      <span className="font-bold text-slate-900 text-sm">
                        Pedido #{o.orderNumber}
                      </span>
                      <span className="text-xs text-slate-400 ml-2">
                        {new Date(o.createdAt).toLocaleDateString('pt-MZ')}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">Estado:</span>
                      <span className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        o.status === 'pago'
                          ? 'bg-emerald-100 text-emerald-800'
                          : o.status === 'enviado'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {o.status}
                      </span>
                    </div>
                  </div>

                  {/* Items and Customer details */}
                  <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <div>
                      <h4 className="font-bold text-slate-700 mb-2">Artigos Encomendados:</h4>
                      <div className="space-y-2">
                        {o.items
                          .filter((i) => i.sellerId === user.id)
                          .map((item, idx) => (
                            <div key={idx} className="flex justify-between items-center bg-slate-50 p-2 rounded">
                              <span className="font-medium text-slate-900">{item.title}</span>
                              <span className="font-mono tabular-nums text-slate-700">
                                {item.quantity} {item.unitType}(s) × {formatPrice(item.price)}
                              </span>
                            </div>
                          ))}
                      </div>

                      <div className="mt-3 pt-2 border-t border-slate-100 text-slate-600 flex justify-between">
                        <span>Valor líquido devido ao vendedor (após comissão 5%):</span>
                        <strong className="text-emerald-700 font-mono text-sm">
                          {formatPrice(o.sellerPayout)}
                        </strong>
                      </div>
                    </div>

                    <div className="bg-slate-50 p-3 rounded-lg space-y-1">
                      <h4 className="font-bold text-slate-700">Dados do Comprador & Entrega:</h4>
                      <p className="text-slate-900 font-semibold">{o.buyerName}</p>
                      <p className="text-slate-600">Contacto: {o.buyerPhone}</p>
                      <p className="text-slate-600">
                        Destino: {o.deliveryAddress.province}, {o.deliveryAddress.city}
                      </p>
                      <p className="text-slate-600">Morada: {o.deliveryAddress.street}</p>
                      {o.deliveryAddress.notes && (
                        <p className="text-amber-800 italic">Notas: {o.deliveryAddress.notes}</p>
                      )}
                    </div>
                  </div>

                  {/* Seller action status selector */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Atualizar progresso do envio:</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleUpdateOrderStatus(o.id, 'em_preparacao')}
                        className="py-1 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-medium cursor-pointer"
                      >
                        Em Preparação
                      </button>
                      <button
                        onClick={() => handleUpdateOrderStatus(o.id, 'enviado')}
                        className="py-1 px-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded font-semibold cursor-pointer"
                      >
                        Marcar como Enviado
                      </button>
                      <button
                        onClick={() => handleUpdateOrderStatus(o.id, 'concluido')}
                        className="py-1 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded font-semibold cursor-pointer"
                      >
                        Concluído / Entregue
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: New Product Form */}
      {activeTab === 'new_product' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 max-w-2xl mx-auto shadow-xs">
          <h2 className="text-lg font-bold text-slate-900 mb-1 font-display">
            Publicar Novo Artigo no Moz Fácil Fal
          </h2>
          <p className="text-xs text-slate-500 mb-6">
            O seu anúncio ficará disponível para todo o território moçambicano.
          </p>

          {message && (
            <div
              className={`p-3 rounded-lg text-xs mb-4 flex items-start gap-2 ${
                message.type === 'success'
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                  : 'bg-rose-50 border border-rose-200 text-rose-700'
              }`}
            >
              {message.type === 'success' ? (
                <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              )}
              <span>{message.text}</span>
            </div>
          )}

          <form onSubmit={handleCreateProduct} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Título do Produto
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Cimento Nacional 42.5N ou Castanha de Caju de Nampula..."
                className="w-full py-2.5 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Categoria</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Unidade de Medida
                </label>
                <select
                  value={unitType}
                  onChange={(e) => setUnitType(e.target.value)}
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white"
                >
                  {UNIT_TYPES.map((u) => (
                    <option key={u} value={u}>
                      por {u}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Preço Base (MTn)
                </label>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="Ex: 850"
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Qtd. Mínima (MOQ)
                </label>
                <input
                  type="number"
                  min="1"
                  value={moq}
                  onChange={(e) => setMoq(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Preço Atacado (MTn)
                </label>
                <input
                  type="number"
                  value={wholesalePrice}
                  onChange={(e) => setWholesalePrice(e.target.value)}
                  placeholder="Ex: 780"
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Atacado a partir de
                </label>
                <input
                  type="number"
                  value={wholesaleMinQty}
                  onChange={(e) => setWholesaleMinQty(e.target.value)}
                  placeholder="Ex: 10"
                  className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Stock Disponível
              </label>
              <input
                type="number"
                min="0"
                value={stock}
                onChange={(e) => setStock(parseInt(e.target.value) || 0)}
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none font-mono"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Imagem do Produto (URL ou Seleção)
              </label>
              <select
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white mb-2"
              >
                <option value="/src/assets/images/product_agri_produce_1792475627909.jpg">
                  Agricultura & Grãos (Castanha de Caju, Milho)
                </option>
                <option value="/src/assets/images/product_electronics_solar_1792475628923.jpg">
                  Eletrónica & Energia Solar
                </option>
                <option value="/src/assets/images/product_construction_hardware_1792475629674.jpg">
                  Construção Civil & Materiais
                </option>
                <option value="/src/assets/images/hero_moz_marketplace_1792475627934.jpg">
                  Comércio & Logística Geral
                </option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Descrição Completa
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Detalhes sobre a origem, especificações, garantia, embalagem..."
                rows={4}
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Condições de Entrega & Frete
              </label>
              <input
                type="text"
                value={deliveryInfo}
                onChange={(e) => setDeliveryInfo(e.target.value)}
                placeholder="Ex: Entregas em 24h na Grande Maputo. Despachos provinciais via camião."
                className="w-full py-2 px-3 border border-slate-300 rounded-lg outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer shadow-md"
            >
              {saving ? 'A guardar...' : 'Publicar Anúncio no Marketplace'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
