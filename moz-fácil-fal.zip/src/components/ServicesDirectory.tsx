import React, { useState } from 'react';
import {
  Wrench,
  MapPin,
  ShieldCheck,
  Phone,
  MessageSquare,
  Search,
  CheckCircle,
  Clock,
  PlusCircle,
} from 'lucide-react';
import { ServiceItem, User } from '../types/index.ts';

interface ServicesDirectoryProps {
  services: ServiceItem[];
  user: User | null;
  onContactProvider: (service: ServiceItem) => void;
  onOpenNewService: () => void;
  onOpenAuth: () => void;
}

const SERVICE_CATEGORIES = [
  'Todos',
  'Reparação & Assistência Técnica',
  'Eletricistas & Canalizadores',
  'Transporte & Cargas',
  'Construção Civil & Obras',
  'Informática & Design Gráfico',
  'Limpeza & Serviços Gerais',
  'Consultoria & Explicações',
];

export const ServicesDirectory: React.FC<ServicesDirectoryProps> = ({
  services,
  user,
  onContactProvider,
  onOpenNewService,
  onOpenAuth,
}) => {
  const [selectedCat, setSelectedCat] = useState('Todos');
  const [search, setSearch] = useState('');

  const filtered = services.filter((s) => {
    const matchCat =
      selectedCat === 'Todos' ||
      s.category.toLowerCase().includes(selectedCat.toLowerCase());
    const matchSearch =
      !search ||
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.description.toLowerCase().includes(search.toLowerCase()) ||
      s.providerName.toLowerCase().includes(search.toLowerCase()) ||
      s.providerCity.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Services Hero Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 rounded-2xl p-6 sm:p-10 text-white mb-8 shadow-xl">
        <div className="max-w-2xl">
          <span className="text-xs uppercase font-bold tracking-wider text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-sm border border-amber-400/20">
            Serviços & Profissionais de Moçambique
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display mt-3 mb-2 leading-tight">
            Contrate Especialistas & Técnicos Verificados
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-6">
            Eletricistas, mecânicos, técnicos de informática, reparação de telemóveis, motoristas e prestadores de serviços de confiança em todas as províncias.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                if (!user) onOpenAuth();
                else onOpenNewService();
              }}
              className="py-2.5 px-4 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-md"
            >
              <PlusCircle className="w-4 h-4" />
              Anunciar o Meu Serviço
            </button>
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Contacto direto sem intermediários</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 no-scrollbar text-xs">
          {SERVICE_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCat(cat)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer font-medium ${
                selectedCat === cat
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative min-w-[260px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Pesquisar eletricista, técnico..."
            className="w-full text-xs py-2 pl-9 pr-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500 bg-white"
          />
        </div>
      </div>

      {/* Services Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8">
          <Wrench className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-semibold text-slate-800 text-base">Nenhum serviço encontrado</h3>
          <p className="text-xs text-slate-500 mt-1">
            Experimente alterar os termos de pesquisa ou selecionar outra categoria.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-slate-300 hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Image */}
                <div className="aspect-16/9 bg-slate-100 overflow-hidden relative">
                  <img
                    src={service.images[0] || '/src/assets/images/service_technician_repair_1792475629469.jpg'}
                    alt={service.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded">
                    {service.category}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1.5">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-amber-500" />
                      {service.providerCity}
                    </span>
                    <span className="flex items-center gap-1 text-slate-400">
                      <Clock className="w-3 h-3" />
                      {service.availability || 'Disponível'}
                    </span>
                  </div>

                  <h3 className="font-semibold text-slate-900 text-sm mb-2 line-clamp-2 leading-snug">
                    {service.title}
                  </h3>

                  <p className="text-xs text-slate-600 line-clamp-3 mb-4 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Price */}
                  <div className="flex items-baseline gap-1.5 mb-3 p-2 bg-slate-50 rounded-lg">
                    <span className="text-xs text-slate-500">A partir de:</span>
                    <span className="font-extrabold text-slate-900 font-mono text-base tabular-nums">
                      {service.price > 0 ? service.price.toLocaleString('pt-MZ') + ' MTn' : 'A Negociar'}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      /{service.priceUnit || 'serviço'}
                    </span>
                    {service.isNegotiable && (
                      <span className="text-[10px] text-amber-700 font-semibold ml-auto">
                        Negociável
                      </span>
                    )}
                  </div>

                  {/* Provider Info */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="font-medium truncate max-w-[150px]">
                        {service.providerName}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="p-4 pt-0 flex gap-2">
                <button
                  onClick={() => onContactProvider(service)}
                  className="flex-1 py-2 px-3 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Pedir Orçamento
                </button>
                <a
                  href={`tel:${service.providerPhone}`}
                  className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
                  title="Contactar por Telefone"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
