import React from 'react';
import { Heart, ShoppingBag } from 'lucide-react';
import { Product } from '../types/index.ts';
import { ProductCard } from './ProductCard.tsx';

interface FavoritesViewProps {
  products: Product[];
  favoriteIds: string[];
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onViewDetails: (product: Product) => void;
  onExploreCatalog: () => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  products,
  favoriteIds,
  onToggleFavorite,
  onAddToCart,
  onViewDetails,
  onExploreCatalog,
}) => {
  const favoriteProducts = products.filter((p) => favoriteIds.includes(p.id));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-6">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
          Meus Favoritos
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          {favoriteProducts.length} artigos guardados para compra futura
        </p>
      </div>

      {favoriteProducts.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8">
          <Heart className="w-16 h-16 text-slate-300 mx-auto mb-3" />
          <h3 className="font-semibold text-slate-800 text-base mb-1">
            Nenhum produto nos seus favoritos
          </h3>
          <p className="text-xs text-slate-500 mb-6">
            Clique no ícone de coração nos produtos que deseja acompanhar.
          </p>
          <button
            onClick={onExploreCatalog}
            className="py-2.5 px-6 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-xl cursor-pointer"
          >
            Explorar Catálogo
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {favoriteProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              isFavorite={true}
              onToggleFavorite={onToggleFavorite}
              onAddToCart={onAddToCart}
              onViewDetails={onViewDetails}
            />
          ))}
        </div>
      )}
    </div>
  );
};
