import React, { useState } from 'react';
import { X, Sparkles, Search, ArrowRight, CheckCircle2, Package } from 'lucide-react';
import { api } from '../services/api.ts';
import { Product } from '../types/index.ts';

interface AISearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
}

const SAMPLE_QUERIES = [
  'Quero comprar castanha de caju de primeira qualidade para exportação',
  'Preciso de gerador solar e bateria para cortes de energia em Maputo',
  'Procuro cimento e azulejos para obra na província de Sofala',
  'Telefone resistente com bateria de longa duração para trabalho rural',
];

export const AISearchModal: React.FC<AISearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
}) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    explanation: string;
    matchingProducts: Product[];
    parsed?: any;
  } | null>(null);

  if (!isOpen) return null;

  const handleSearch = async (queryText: string) => {
    if (!queryText.trim()) return;
    setLoading(true);
    setResult(null);

    try {
      const data = await api.smartSearch(queryText.trim());
      setResult({
        explanation: data.explanation,
        matchingProducts: data.matchingProducts,
        parsed: data.parsed,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200 my-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-xs flex items-center justify-center font-bold text-white text-sm">
              <Sparkles className="w-4 h-4 text-amber-100" />
            </div>
            <div>
              <h3 className="font-bold text-base font-display">
                Pesquisa Inteligente Assistida por IA
              </h3>
              <p className="text-xs text-amber-100">
                Encontre o produto ou fornecedor ideal descrevendo a sua necessidade
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch(prompt);
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Ex: Procuro cimento Portland de alta resistência para entregar em Beira..."
                className="w-full text-xs py-2.5 pl-9 pr-3 border border-slate-300 rounded-xl outline-none focus:border-amber-500 bg-white"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5" />
              {loading ? 'A analisar...' : 'Pesquisar com IA'}
            </button>
          </form>

          {/* Quick samples */}
          <div>
            <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
              Sugestões Rápidas:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_QUERIES.map((q, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setPrompt(q);
                    handleSearch(q);
                  }}
                  className="text-[11px] py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer text-left"
                >
                  "{q}"
                </button>
              ))}
            </div>
          </div>

          {/* AI Response area */}
          {result && (
            <div className="pt-4 border-t border-slate-200 space-y-3">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold block">Interpretação da IA:</span>
                  <p className="text-amber-800 mt-0.5">{result.explanation}</p>
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-700 block mb-2">
                  Produtos Correspondentes ({result.matchingProducts.length}):
                </span>

                {result.matchingProducts.length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-4 text-center">
                    Nenhum produto correspondeu diretamente aos critérios da pesquisa.
                  </p>
                ) : (
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {result.matchingProducts.map((p) => (
                      <div
                        key={p.id}
                        onClick={() => {
                          onSelectProduct(p);
                          onClose();
                        }}
                        className="p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg flex items-center justify-between cursor-pointer transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={p.images[0] || ''}
                            alt=""
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 rounded object-cover bg-white border border-slate-200 shrink-0"
                          />
                          <div>
                            <span className="font-semibold text-slate-900 text-xs block line-clamp-1">
                              {p.title}
                            </span>
                            <span className="text-[11px] text-slate-500">
                              {p.sellerName} · {p.sellerCity}
                            </span>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="font-mono font-bold text-slate-900 text-xs block">
                            {formatPrice(p.price)}
                          </span>
                          <span className="text-[10px] text-slate-400">/{p.unitType}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
