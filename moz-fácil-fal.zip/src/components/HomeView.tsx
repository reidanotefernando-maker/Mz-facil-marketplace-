import React from 'react';
import {
  ShieldCheck,
  Building2,
  ArrowRight,
  TrendingUp,
  MapPin,
  Truck,
  Sparkles,
  CheckCircle2,
  PhoneCall,
  DollarSign,
  Package,
} from 'lucide-react';
import { Product, ServiceItem, User } from '../types/index.ts';
import { ProductCard } from './ProductCard.tsx';

interface HomeViewProps {
  products: Product[];
  services: ServiceItem[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onViewProductDetails: (product: Product) => void;
  onViewServiceDetails: (service: ServiceItem) => void;
  onOpenRFQ: () => void;
  onSelectCategory: (category: string) => void;
  setActiveTab: (tab: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  products,
  services,
  favorites,
  onToggleFavorite,
  onAddToCart,
  onViewProductDetails,
  onViewServiceDetails,
  onOpenRFQ,
  onSelectCategory,
  setActiveTab,
}) => {
  const featuredProducts = products.slice(0, 6);
  const featuredServices = services.slice(0, 3);

  return (
    <div className="space-y-12 pb-16">
      {/* 1. Alibaba-Grade Marketplace Hero Split */}
      <section className="bg-slate-900 text-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Col: Hero Pitch */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                O Maior Marketplace & Diretório de Moçambique
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display tracking-tight leading-tight text-white">
                Compre, Venda & Contrate Fornecedores em Moçambique
              </h1>

              <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl">
                Ligue-se diretamente a produtores agrícolas em Nampula, fabricantes na Matola, fornecedores na Beira e técnicos qualificados em Maputo. Pagamentos 100% seguros com M-Pesa e e-Mola.
              </p>

              {/* Quick Actions */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => setActiveTab('produtos')}
                  className="py-3 px-6 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm rounded-xl transition-colors cursor-pointer shadow-lg flex items-center gap-2"
                >
                  <Package className="w-4 h-4" />
                  Explorar Catálogo de Produtos
                </button>
                <button
                  onClick={onOpenRFQ}
                  className="py-3 px-6 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs sm:text-sm rounded-xl transition-colors cursor-pointer border border-slate-700 flex items-center gap-2"
                >
                  <Building2 className="w-4 h-4 text-amber-400" />
                  Solicitar Cotação (RFQ)
                </button>
              </div>

              {/* Trust markers */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-800 text-xs">
                <div>
                  <span className="font-extrabold text-white text-lg font-mono block">100% MZ</span>
                  <span className="text-slate-400">11 Províncias</span>
                </div>
                <div>
                  <span className="font-extrabold text-amber-400 text-lg font-mono block">M-Pesa & e-Mola</span>
                  <span className="text-slate-400">Pagamento Seguro</span>
                </div>
                <div>
                  <span className="font-extrabold text-emerald-400 text-lg font-mono block">5%</span>
                  <span className="text-slate-400">Menor Comissão</span>
                </div>
              </div>
            </div>

            {/* Right Col: Hero Image Card */}
            <div className="lg:col-span-5 relative">
              <div className="aspect-16/10 rounded-2xl overflow-hidden shadow-2xl border border-slate-700 bg-slate-800 relative group">
                <img
                  src="/src/assets/images/hero_moz_marketplace_1792475627934.jpg"
                  alt="Mercado Atacadista de Moçambique"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex flex-col justify-end p-5">
                  <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/20 text-xs text-white">
                    <p className="font-bold flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      Fornecedores & Produtores Certificados
                    </p>
                    <p className="text-slate-300 text-[11px] mt-0.5">
                      Agroindústria, ferragens, energia solar e eletrónica com entrega nacional.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Category Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
              Comprar por Categoria
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Setores estratégicos da economia de Moçambique
            </p>
          </div>
          <button
            onClick={() => setActiveTab('produtos')}
            className="text-xs font-semibold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Ver Todas</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div
            onClick={() => onSelectCategory('Agricultura & Alimentos')}
            className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-amber-400 hover:shadow-md transition-all cursor-pointer p-4 text-center"
          >
            <div className="aspect-square rounded-lg overflow-hidden bg-slate-100 mb-3 relative">
              <img
                src="/src/assets/images/product_agri_produce_1792475627909.jpg"
                alt="Agricultura"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <h3 className="font-bold text-slate-900 text-xs sm:text-sm group-hover:text-amber-600 transition-colors">
              Agricultura & Caju
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Grãos, cereais, castanha</p>
          </div>

          <div
            onClick={() => onSelectCategory('Tecnologia & Eletrónica')}
            className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-amber-400 hover:shadow-md transition-all cursor-pointer p-4 text-center"
          >
            <div className="aspect-square rounded-lg overflow-hidden bg-slate-100 mb-3 relative">
              <img
                src="/src/assets/images/product_electronics_solar_1792475628923.jpg"
                alt="Energia Solar & Telemóveis"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <h3 className="font-bold text-slate-900 text-xs sm:text-sm group-hover:text-amber-600 transition-colors">
              Energia Solar & Tech
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Baterias, telefones, painéis</p>
          </div>

          <div
            onClick={() => onSelectCategory('Construção & Ferragens')}
            className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-amber-400 hover:shadow-md transition-all cursor-pointer p-4 text-center"
          >
            <div className="aspect-square rounded-lg overflow-hidden bg-slate-100 mb-3 relative">
              <img
                src="/src/assets/images/product_construction_hardware_1792475629674.jpg"
                alt="Construção Civil"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <h3 className="font-bold text-slate-900 text-xs sm:text-sm group-hover:text-amber-600 transition-colors">
              Construção Civil
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Cimento, azulejos, varão</p>
          </div>

          <div
            onClick={() => setActiveTab('servicos')}
            className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-amber-400 hover:shadow-md transition-all cursor-pointer p-4 text-center"
          >
            <div className="aspect-square rounded-lg overflow-hidden bg-slate-100 mb-3 relative">
              <img
                src="/src/assets/images/service_technician_repair_1792475629469.jpg"
                alt="Serviços & Assistência"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <h3 className="font-bold text-slate-900 text-xs sm:text-sm group-hover:text-amber-600 transition-colors">
              Serviços Especializados
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Reparação, fretes, eletricistas</p>
          </div>
        </div>
      </section>

      {/* 3. Featured Wholesale & Retail Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
              Produtos em Destaque & Preço Atacado
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Valores em Meticais (MTn) com quantidade mínima (MOQ)
            </p>
          </div>
          <button
            onClick={() => setActiveTab('produtos')}
            className="text-xs font-semibold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Ver Catálogo Completo</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {featuredProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              isFavorite={favorites.includes(p.id)}
              onToggleFavorite={onToggleFavorite}
              onAddToCart={onAddToCart}
              onViewDetails={onViewProductDetails}
            />
          ))}
        </div>
      </section>

      {/* 4. RFQ Callout Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl p-6 sm:p-10 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-xl">
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-900 text-white">
              Cotação Sob Medida
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold font-display mt-2 leading-tight">
              Não encontrou o que procura? Solicite aos fornecedores!
            </h3>
            <p className="text-amber-100 text-xs sm:text-sm mt-2 leading-relaxed">
              Diga o produto, quantidade e província de entrega. Produtores e fornecedores credenciados enviarão orçamentos competitivos diretamente para si.
            </p>
          </div>

          <button
            onClick={onOpenRFQ}
            className="py-3 px-6 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-xl transition-colors cursor-pointer shadow-lg shrink-0 flex items-center gap-2"
          >
            <Building2 className="w-4 h-4 text-amber-400" />
            Criar Pedido de Cotação
          </button>
        </div>
      </section>

      {/* 5. Top Local Services */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
              Serviços & Profissionais em Destaque
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Profissionais recomendados e credenciados em Moçambique
            </p>
          </div>
          <button
            onClick={() => setActiveTab('servicos')}
            className="text-xs font-semibold text-amber-600 hover:text-amber-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Ver Todos os Serviços</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredServices.map((service) => (
            <div
              key={service.id}
              onClick={() => onViewServiceDetails(service)}
              className="bg-white rounded-xl border border-slate-200 p-4 hover:border-amber-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="aspect-16/9 rounded-lg overflow-hidden bg-slate-100 mb-3 relative">
                  <img
                    src={service.images[0] || '/src/assets/images/service_technician_repair_1792475629469.jpg'}
                    alt={service.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute top-2 left-2 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded">
                    {service.category}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                  <span className="flex items-center gap-0.5">
                    <MapPin className="w-3 h-3 text-amber-500" />
                    {service.providerCity}
                  </span>
                  <span className="text-emerald-700 font-semibold">
                    {service.providerName}
                  </span>
                </div>

                <h3 className="font-semibold text-slate-900 text-sm mb-2 line-clamp-2 leading-snug">
                  {service.title}
                </h3>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Preço base:</span>
                  <span className="font-bold text-slate-900 font-mono tabular-nums">
                    {service.price > 0 ? service.price.toLocaleString('pt-MZ') + ' MTn' : 'Negociável'}
                  </span>
                </div>
                <span className="text-amber-600 font-semibold hover:underline">
                  Pedir Orçamento →
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
