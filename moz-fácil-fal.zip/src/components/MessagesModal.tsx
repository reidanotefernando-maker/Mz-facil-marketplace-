import React, { useState, useEffect } from 'react';
import { X, Send, MessageSquare, User as UserIcon, AlertCircle, ShoppingBag } from 'lucide-react';
import { MessageItem, User } from '../types/index.ts';
import { api } from '../services/api.ts';

interface MessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  targetUser?: { id: string; name: string } | null;
  reference?: { type: string; id: string; title: string } | null;
  onOpenAuth: () => void;
}

export const MessagesModal: React.FC<MessagesModalProps> = ({
  isOpen,
  onClose,
  user,
  targetUser,
  reference,
  onOpenAuth,
}) => {
  const [messages, setMessages] = useState<MessageItem[]>([]);
  const [selectedThread, setSelectedThread] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (isOpen && user) {
      loadMessages();
    }
  }, [isOpen, user]);

  const loadMessages = async () => {
    setLoading(true);
    try {
      const list = await api.getMessages();
      setMessages(list);

      // Group threads
      if (targetUser) {
        // Find existing thread or start a new conversation
        const match = list.find(
          (m) =>
            (m.senderId === targetUser.id && m.receiverId === user?.id) ||
            (m.senderId === user?.id && m.receiverId === targetUser.id)
        );
        if (match) {
          setSelectedThread(match.threadId);
        } else {
          setSelectedThread('new_thread_' + targetUser.id);
        }
      } else if (list.length > 0 && !selectedThread) {
        setSelectedThread(list[0].threadId);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  // Group threads
  const threadsMap = new Map<string, { threadId: string; otherId: string; otherName: string; lastMessage: MessageItem; count: number }>();

  messages.forEach((m) => {
    const isSender = m.senderId === user?.id;
    const otherId = isSender ? m.receiverId : m.senderId;
    const otherName = isSender ? m.receiverName : m.senderName;

    if (!threadsMap.has(m.threadId)) {
      threadsMap.set(m.threadId, {
        threadId: m.threadId,
        otherId,
        otherName,
        lastMessage: m,
        count: 1,
      });
    } else {
      const existing = threadsMap.get(m.threadId)!;
      existing.lastMessage = m;
      existing.count += 1;
    }
  });

  const threads = Array.from(threadsMap.values());

  const currentMessages = messages.filter((m) => m.threadId === selectedThread);
  const activeThreadInfo = threads.find((t) => t.threadId === selectedThread);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !user) return;

    let receiverId = targetUser?.id || activeThreadInfo?.otherId;
    let receiverName = targetUser?.name || activeThreadInfo?.otherName;

    if (!receiverId) return;

    setSending(true);
    try {
      const newMsg = await api.sendMessage({
        receiverId,
        receiverName: receiverName || 'Utilizador',
        content: replyText.trim(),
        referenceType: reference?.type,
        referenceId: reference?.id,
        referenceTitle: reference?.title,
      });

      setMessages((prev) => [...prev, newMsg]);
      setSelectedThread(newMsg.threadId);
      setReplyText('');
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full h-[600px] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-sm sm:text-base font-display">
              Mensagens & Negociações
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!user ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <MessageSquare className="w-12 h-12 text-slate-300 mb-3" />
            <h4 className="font-semibold text-slate-800 text-base mb-1">
              Inicie sessão para ver as suas mensagens
            </h4>
            <p className="text-xs text-slate-500 mb-4">
              Conecte-se com agricultores, importadores e vendedores em Moçambique.
            </p>
            <button
              onClick={() => {
                onClose();
                onOpenAuth();
              }}
              className="py-2.5 px-5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              Entrar com Telefone
            </button>
          </div>
        ) : (
          <div className="flex-1 flex min-h-0">
            {/* Sidebar with conversations */}
            <div className="w-1/3 border-r border-slate-200 flex flex-col bg-slate-50 overflow-y-auto">
              <div className="p-3 border-b border-slate-200 bg-white font-semibold text-xs text-slate-700">
                Conversas Ativas
              </div>

              {threads.length === 0 && !targetUser && (
                <div className="p-4 text-center text-xs text-slate-400">
                  Nenhuma mensagem ainda.
                </div>
              )}

              {targetUser && !threadsMap.has(selectedThread || '') && (
                <div
                  className={`p-3 border-b border-slate-200 cursor-pointer bg-amber-50 text-amber-900 text-xs`}
                >
                  <p className="font-bold">{targetUser.name}</p>
                  <p className="text-[11px] text-amber-700">Nova conversa em curso...</p>
                </div>
              )}

              {threads.map((t) => (
                <div
                  key={t.threadId}
                  onClick={() => setSelectedThread(t.threadId)}
                  className={`p-3 border-b border-slate-200 cursor-pointer transition-colors text-xs ${
                    selectedThread === t.threadId
                      ? 'bg-amber-500/10 border-l-4 border-l-amber-500'
                      : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-900 truncate">
                      {t.otherName}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(t.lastMessage.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 truncate">
                    {t.lastMessage.content}
                  </p>
                </div>
              ))}
            </div>

            {/* Main Chat Thread */}
            <div className="flex-1 flex flex-col bg-white">
              {/* Thread Context banner */}
              <div className="p-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700 text-xs">
                    <UserIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900">
                      {targetUser?.name || activeThreadInfo?.otherName || 'Conversa'}
                    </span>
                    {reference && (
                      <span className="block text-[10px] text-amber-600 truncate max-w-xs">
                        Ref: {reference.title}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Messages Bubble List */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {currentMessages.length === 0 ? (
                  <div className="text-center py-12 text-xs text-slate-400">
                    Escreva uma mensagem para iniciar a negociação direta.
                  </div>
                ) : (
                  currentMessages.map((msg) => {
                    const isMe = msg.senderId === user.id;
                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[75%] p-3 rounded-2xl text-xs leading-relaxed ${
                            isMe
                              ? 'bg-amber-500 text-white rounded-br-none'
                              : 'bg-slate-100 text-slate-800 rounded-bl-none'
                          }`}
                        >
                          {msg.referenceTitle && (
                            <div
                              className={`text-[10px] pb-1 mb-1 border-b ${
                                isMe ? 'border-amber-400/40 text-amber-100' : 'border-slate-200 text-slate-500'
                              }`}
                            >
                              Produto: {msg.referenceTitle}
                            </div>
                          )}
                          <p>{msg.content}</p>
                        </div>
                        <span className="text-[10px] text-slate-400 mt-1 px-1">
                          {new Date(msg.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-200 flex gap-2">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Escreva a sua mensagem ou proposta de preço..."
                  className="flex-1 text-xs py-2 px-3 border border-slate-200 rounded-lg outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  disabled={sending || !replyText.trim()}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold text-xs rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Enviar</span>
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
