import React, { useState } from 'react';
import { X, Building2, Send, AlertCircle, CheckCircle } from 'lucide-react';
import { api } from '../services/api.ts';
import { User, RFQItem } from '../types/index.ts';

interface RFQModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onRFQCreated: (rfq: RFQItem) => void;
  onOpenAuth: () => void;
}

const CATEGORIES = [
  'Construção & Ferragens',
  'Agricultura & Alimentos',
  'Tecnologia & Eletrónica',
  'Serviços Técnicos & Reparação',
  'Transporte & Cargas',
  'Moda, Tecidos & Capulanas',
  'Eletrodomésticos & Casa',
];

const PROVINCES = [
  'Maputo Cidade',
  'Maputo Província',
  'Gaza',
  'Inhambane',
  'Sofala',
  'Manica',
  'Tete',
  'Zambézia',
  'Nampula',
  'Cabo Delgado',
  'Niassa',
];

export const RFQModal: React.FC<RFQModalProps> = ({
  isOpen,
  onClose,
  user,
  onRFQCreated,
  onOpenAuth,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [description, setDescription] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [targetPrice, setTargetPrice] = useState('');
  const [city, setCity] = useState(user?.city || 'Maputo');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }

    if (!title.trim() || !description.trim()) {
      setError('Por favor preencha o título e os detalhes da sua necessidade.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const newRFQ = await api.createRFQ({
        title: title.trim(),
        category,
        description: description.trim(),
        quantity: Number(quantity),
        targetPrice: targetPrice ? Number(targetPrice) : undefined,
        city: city || 'Maputo',
      });

      setSuccess(true);
      onRFQCreated(newRFQ);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Erro ao publicar solicitação de cotação.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 my-auto">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center font-bold text-white text-sm">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base font-display">Solicitar Orçamento (RFQ)</h3>
              <p className="text-xs text-slate-400">Receba propostas de fornecedores em Moçambique</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2">
              <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>Cotação publicada! Os fornecedores certificados foram notificados.</span>
            </div>
          )}

          {!user && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
              <p className="font-semibold mb-1">Inicie sessão para enviar cotações</p>
              <button
                type="button"
                onClick={onOpenAuth}
                className="mt-1 font-semibold text-amber-800 hover:underline"
              >
                Clique aqui para entrar com o seu telemóvel →
              </button>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              O que precisa de comprar ou contratar?
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Cimento 42.5N para obra, 5 toneladas de castanha de caju, frete..."
              className="w-full text-xs py-2.5 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500 bg-white"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Categoria</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-xs py-2 px-2.5 border border-slate-300 rounded-lg outline-none bg-white"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Local de Entrega
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Ex: Maputo, Beira, Nampula"
                className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Quantidade</label>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Preço Alvo Unitário (MTn, Opcional)
              </label>
              <input
                type="number"
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
                placeholder="Ex: 850"
                className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg outline-none bg-white font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Detalhes, especificações e prazos
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descreva marca pretendida, qualidade, prazos de entrega e quaisquer condições especiais..."
              rows={4}
              className="w-full text-xs py-2.5 px-3 border border-slate-300 rounded-lg outline-none focus:border-amber-500 bg-white"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading || !user}
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            <Send className="w-4 h-4 text-amber-400" />
            {loading ? 'A publicar...' : 'Publicar Solicitação de Cotação'}
          </button>
        </form>
      </div>
    </div>
  );
};
