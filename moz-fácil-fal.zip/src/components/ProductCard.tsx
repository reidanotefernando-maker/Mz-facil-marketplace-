import React, { useState } from 'react';
import { Heart, ShoppingCart, MapPin, ShieldCheck, Image as ImageIcon } from 'lucide-react';
import { Product } from '../types/index.ts';

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onViewDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isFavorite,
  onToggleFavorite,
  onAddToCart,
  onViewDetails,
}) => {
  const [imageError, setImageError] = useState(false);

  const formatPrice = (val: number) => {
    return val.toLocaleString('pt-MZ') + ' MTn';
  };

  const imageSrc = product.images?.[0] || '';

  return (
    <div className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-slate-300 hover:shadow-md transition-all duration-200 flex flex-col justify-between">
      <div>
        {/* Product Image Area */}
        <div
          onClick={() => onViewDetails(product)}
          className="relative aspect-4/3 bg-slate-100 overflow-hidden cursor-pointer"
        >
          {!imageError && imageSrc ? (
            <img
              src={imageSrc}
              alt={product.title}
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-slate-100 text-slate-400">
              <ImageIcon className="w-8 h-8 mb-1" />
              <span className="text-[11px] font-medium text-slate-500 text-center line-clamp-1">
                {product.category}
              </span>
            </div>
          )}

          {/* Favorite button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(product.id);
            }}
            className={`absolute top-2.5 right-2.5 p-1.5 rounded-full transition-colors cursor-pointer ${
              isFavorite
                ? 'bg-rose-50 text-rose-500 shadow-xs'
                : 'bg-white/80 backdrop-blur-xs text-slate-500 hover:text-rose-500'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-500' : ''}`} />
          </button>

          {/* MOQ Badge */}
          <div className="absolute bottom-2 left-2 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded">
            Mín: {product.moq} {product.unitType}{product.moq > 1 ? 's' : ''}
          </div>
        </div>

        {/* Card Body */}
        <div className="p-3.5">
          {/* Category & Location */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
            <span className="truncate max-w-[130px] font-medium">{product.category}</span>
            <span className="flex items-center gap-0.5 shrink-0 text-slate-400">
              <MapPin className="w-3 h-3 text-amber-500" />
              {product.sellerCity}
            </span>
          </div>

          {/* Product Title */}
          <h3
            onClick={() => onViewDetails(product)}
            className="font-semibold text-slate-900 text-sm line-clamp-2 hover:text-amber-600 transition-colors cursor-pointer mb-2 min-h-[40px] leading-snug"
          >
            {product.title}
          </h3>

          {/* Pricing area */}
          <div className="mb-2">
            <div className="flex items-baseline gap-1">
              <span className="font-extrabold text-base text-slate-900 font-mono tracking-tight tabular-nums">
                {formatPrice(product.price)}
              </span>
              <span className="text-[11px] text-slate-500 font-normal">
                /{product.unitType}
              </span>
            </div>

            {/* Wholesale bracket */}
            {product.wholesalePrice && product.wholesaleMinQty && (
              <p className="text-[11px] text-emerald-700 font-medium mt-0.5">
                {formatPrice(product.wholesalePrice)} a partir de {product.wholesaleMinQty} {product.unitType}s
              </p>
            )}
          </div>

          {/* Seller line */}
          <div className="flex items-center gap-1 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span className="truncate">{product.sellerName}</span>
          </div>
        </div>
      </div>

      {/* Card Actions */}
      <div className="p-3 pt-0 flex items-center gap-2">
        <button
          onClick={() => onViewDetails(product)}
          className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer text-center"
        >
          Ver Detalhes
        </button>
        <button
          onClick={() => onAddToCart(product, product.moq)}
          className="p-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg transition-colors cursor-pointer shadow-xs shrink-0"
          title={`Adicionar quantidade mínima (${product.moq}) ao carrinho`}
        >
          <ShoppingCart className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
