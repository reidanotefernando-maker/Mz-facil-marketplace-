import React from 'react';
import { Home, Wrench, MessageSquare, ShoppingCart, User as UserIcon, FileText } from 'lucide-react';
import { User } from '../types/index.ts';

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  user: User | null;
  onOpenAuth: () => void;
  onOpenCart: () => void;
  onOpenMessages: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  user,
  onOpenAuth,
  onOpenCart,
  onOpenMessages,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 px-2 py-1.5 md:hidden shadow-lg">
      <div className="flex items-center justify-around text-[10px] font-medium text-slate-500">
        <button
          onClick={() => setActiveTab('inicio')}
          className={`flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'inicio' ? 'text-amber-600 font-semibold' : 'hover:text-slate-900'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>Início</span>
        </button>

        <button
          onClick={() => setActiveTab('servicos')}
          className={`flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'servicos' ? 'text-amber-600 font-semibold' : 'hover:text-slate-900'
          }`}
        >
          <Wrench className="w-5 h-5" />
          <span>Serviços</span>
        </button>

        <button
          onClick={() => setActiveTab('rfqs')}
          className={`flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'rfqs' ? 'text-amber-600 font-semibold' : 'hover:text-slate-900'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span>Cotações</span>
        </button>

        <button
          onClick={onOpenMessages}
          className="flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer hover:text-slate-900 relative"
        >
          <MessageSquare className="w-5 h-5" />
          <span>Mensagens</span>
        </button>

        <button
          onClick={onOpenCart}
          className="flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer hover:text-slate-900 relative"
        >
          <div className="relative">
            <ShoppingCart className="w-5 h-5 text-amber-600" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-amber-500 text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </div>
          <span>Carrinho</span>
        </button>

        <button
          onClick={() => {
            if (!user) {
              onOpenAuth();
            } else {
              setActiveTab('pedidos');
            }
          }}
          className={`flex flex-col items-center gap-0.5 p-1 transition-colors cursor-pointer ${
            activeTab === 'pedidos' || activeTab === 'vendedor' ? 'text-amber-600 font-semibold' : 'hover:text-slate-900'
          }`}
        >
          <UserIcon className="w-5 h-5" />
          <span>{user ? 'Minha Conta' : 'Entrar'}</span>
        </button>
      </div>
    </div>
  );
};
