export type UserRole = 'buyer' | 'seller' | 'admin';

export interface User {
  id: string;
  phone: string;
  name: string;
  role: UserRole;
  businessName?: string;
  province?: string;
  city?: string;
  avatar?: string;
  isVerified?: boolean;
  createdAt: string;
}

export type UnitType = 'unidade' | 'conjunto' | 'kg' | 'saco' | 'tonelada' | 'metro' | 'lote';

export interface Product {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  sellerCity: string;
  title: string;
  description: string;
  price: number; // MZN
  wholesalePrice?: number;
  wholesaleMinQty?: number;
  unitType: UnitType;
  moq: number; // Quantidade Mínima de Encomenda
  stock: number;
  category: string;
  subcategory: string;
  images: string[];
  deliveryInfo: string;
  status: 'ativo' | 'sob_revisao' | 'esgotado' | 'rejeitado';
  rating: number;
  reviewCount: number;
  createdAt: string;
}

export interface ServiceItem {
  id: string;
  providerId: string;
  providerName: string;
  providerPhone: string;
  providerCity: string;
  title: string;
  description: string;
  category: string;
  price: number;
  isNegotiable: boolean;
  priceUnit: string;
  images: string[];
  availability: string;
  isVerified: boolean;
  rating: number;
  reviewCount: number;
  createdAt: string;
}

export interface Quote {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  price: number;
  notes: string;
  createdAt: string;
}

export interface RFQItem {
  id: string;
  buyerId: string;
  buyerName: string;
  buyerPhone: string;
  title: string;
  category: string;
  description: string;
  quantity: number;
  targetPrice?: number;
  city: string;
  status: 'aberto' | 'em_negociacao' | 'atendido';
  quotes: Quote[];
  createdAt: string;
}

export interface OrderItem {
  productId: string;
  title: string;
  price: number;
  quantity: number;
  unitType: UnitType;
  sellerId: string;
  sellerName: string;
  image: string;
}

export type OrderStatus =
  | 'pendente'
  | 'aguardando_pagamento'
  | 'pagamento_sob_verificacao'
  | 'pago'
  | 'em_preparacao'
  | 'enviado'
  | 'concluido'
  | 'cancelado';

export interface Order {
  id: string;
  orderNumber: string;
  buyerId: string;
  buyerName: string;
  buyerPhone: string;
  deliveryAddress: {
    province: string;
    city: string;
    street: string;
    notes?: string;
  };
  items: OrderItem[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  commissionRate: number; // e.g., 0.05 (5%)
  commissionAmount: number;
  sellerPayout: number;
  status: OrderStatus;
  paymentMethod: 'mpesa' | 'emola' | 'a_combinar';
  paymentReference?: string;
  paymentNote?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MessageItem {
  id: string;
  threadId: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  content: string;
  referenceType?: 'product' | 'service' | 'order' | 'rfq';
  referenceId?: string;
  referenceTitle?: string;
  isRead: boolean;
  createdAt: string;
}

export interface Coupon {
  code: string;
  discountPercent?: number;
  discountFixed?: number;
  minOrderAmount: number;
  description: string;
  expiryDate: string;
  isActive: boolean;
}

export interface PlatformSettings {
  commissionRatePercent: number;
  mpesaNumber: string;
  mpesaAccountName: string;
  emolaNumber: string;
  emolaAccountName: string;
  supportPhone: string;
  supportWhatsapp: string;
}
