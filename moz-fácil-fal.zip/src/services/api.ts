import {
  User,
  Product,
  ServiceItem,
  RFQItem,
  Order,
  MessageItem,
  PlatformSettings,
} from '../types/index.ts';

const TOKEN_KEY = 'moz_token';
const USER_KEY = 'moz_user';
const CART_KEY = 'moz_cart';
const FAVORITES_KEY = 'moz_favorites';

export interface CartItem {
  product: Product;
  quantity: number;
}

export const api = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },

  setAuth(token: string, user: User) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },

  clearAuth() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },

  getStoredUser(): User | null {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const res = await fetch(endpoint, {
      ...options,
      headers,
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      throw new Error(data.error || 'Ocorreu um erro na ligação ao servidor.');
    }

    return data as T;
  },

  // Auth
  async register(payload: { name: string; phone: string; password: string; role?: string; businessName?: string; province?: string; city?: string }) {
    const data = await this.request<{ token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    this.setAuth(data.token, data.user);
    return data;
  },

  async login(phone: string, password: string) {
    const data = await this.request<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ phone, password }),
    });
    this.setAuth(data.token, data.user);
    return data;
  },

  async getMe() {
    try {
      const data = await this.request<{ user: User }>('/api/auth/me');
      if (data.user) {
        localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      }
      return data.user;
    } catch {
      this.clearAuth();
      return null;
    }
  },

  async logout() {
    try {
      await this.request('/api/auth/logout', { method: 'POST' });
    } catch {}
    this.clearAuth();
  },

  async becomeSeller(payload: { businessName: string; province: string; city: string }) {
    const data = await this.request<{ user: User }>('/api/auth/become-seller', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (data.user) {
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
    }
    return data.user;
  },

  // Products
  async getProducts(params?: Record<string, string>): Promise<Product[]> {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.request<Product[]>(`/api/products${q}`);
  },

  async getProduct(id: string): Promise<Product> {
    return this.request<Product>(`/api/products/${id}`);
  },

  async createProduct(product: Partial<Product>): Promise<Product> {
    return this.request<Product>('/api/products', {
      method: 'POST',
      body: JSON.stringify(product),
    });
  },

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product> {
    return this.request<Product>(`/api/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteProduct(id: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/api/products/${id}`, {
      method: 'DELETE',
    });
  },

  // Services
  async getServices(params?: Record<string, string>): Promise<ServiceItem[]> {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.request<ServiceItem[]>(`/api/services${q}`);
  },

  async createService(service: Partial<ServiceItem>): Promise<ServiceItem> {
    return this.request<ServiceItem>('/api/services', {
      method: 'POST',
      body: JSON.stringify(service),
    });
  },

  // RFQs
  async getRFQs(): Promise<RFQItem[]> {
    return this.request<RFQItem[]>('/api/rfqs');
  },

  async createRFQ(payload: Partial<RFQItem>): Promise<RFQItem> {
    return this.request<RFQItem>('/api/rfqs', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async submitQuote(rfqId: string, quote: { price: number; notes: string }): Promise<RFQItem> {
    return this.request<RFQItem>(`/api/rfqs/${rfqId}/quote`, {
      method: 'POST',
      body: JSON.stringify(quote),
    });
  },

  // Orders
  async createOrder(payload: {
    items: { productId: string; quantity: number }[];
    deliveryAddress: { province: string; city: string; street: string; notes?: string };
    paymentMethod: string;
    couponCode?: string;
  }): Promise<Order> {
    return this.request<Order>('/api/orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async getOrders(): Promise<Order[]> {
    return this.request<Order[]>('/api/orders');
  },

  async submitPaymentProof(orderId: string, paymentReference: string, paymentNote?: string): Promise<Order> {
    return this.request<Order>(`/api/orders/${orderId}/payment`, {
      method: 'POST',
      body: JSON.stringify({ paymentReference, paymentNote }),
    });
  },

  async updateOrderStatus(orderId: string, status: string): Promise<Order> {
    return this.request<Order>(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  // Messages
  async getMessages(): Promise<MessageItem[]> {
    return this.request<MessageItem[]>('/api/messages');
  },

  async sendMessage(payload: {
    receiverId: string;
    receiverName: string;
    content: string;
    referenceType?: string;
    referenceId?: string;
    referenceTitle?: string;
  }): Promise<MessageItem> {
    return this.request<MessageItem>('/api/messages', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Coupons
  async validateCoupon(code: string, orderAmount: number) {
    return this.request<{ valid: boolean; code: string; description: string; discount: number }>('/api/coupons/validate', {
      method: 'POST',
      body: JSON.stringify({ code, orderAmount }),
    });
  },

  // Admin
  async getAdminStats() {
    return this.request<{
      totalUsers: number;
      totalProducts: number;
      totalServices: number;
      totalOrders: number;
      totalGMV: number;
      totalCommission: number;
      pendingPayments: number;
      pendingModeration: number;
      openRFQs: number;
    }>('/api/admin/stats');
  },

  async verifyPayment(orderId: string, approved: boolean, reason?: string) {
    return this.request<{ success: boolean; order: Order }>('/api/admin/verify-payment', {
      method: 'POST',
      body: JSON.stringify({ orderId, approved, reason }),
    });
  },

  async getAdminSettings(): Promise<PlatformSettings> {
    return this.request<PlatformSettings>('/api/admin/settings');
  },

  async updateAdminSettings(settings: Partial<PlatformSettings>): Promise<PlatformSettings> {
    return this.request<PlatformSettings>('/api/admin/settings', {
      method: 'POST',
      body: JSON.stringify(settings),
    });
  },

  async getPaymentInfo() {
    return this.request<{
      mpesaNumber: string;
      mpesaAccountName: string;
      emolaNumber: string;
      emolaAccountName: string;
      supportPhone: string;
      supportWhatsapp: string;
    }>('/api/payment-info');
  },

  async smartSearch(query: string) {
    return this.request<{
      intent: string;
      matchingProducts: Product[];
      explanation: string;
      parsed?: any;
    }>('/api/ai/smart-search', {
      method: 'POST',
      body: JSON.stringify({ query }),
    });
  },

  // Local storage cart
  getCart(): CartItem[] {
    const raw = localStorage.getItem(CART_KEY);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  saveCart(items: CartItem[]) {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
  },

  // Local storage favorites
  getFavorites(): string[] {
    const raw = localStorage.getItem(FAVORITES_KEY);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  toggleFavorite(productId: string): string[] {
    const list = this.getFavorites();
    const idx = list.indexOf(productId);
    if (idx === -1) {
      list.push(productId);
    } else {
      list.splice(idx, 1);
    }
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(list));
    return list;
  },
};
